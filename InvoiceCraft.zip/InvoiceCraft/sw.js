const CACHE='invoicecraft-3.0.2';
const ASSETS=['./','index.html','guide.html','Audit-3.0.0.html','manifest.webmanifest','icons/favicon-32.png','icons/icon.svg','lib/xlsx.full.min.js','lib/html2canvas.min.js','lib/jspdf.umd.min.js','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)));self.skipWaiting()});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE&&(/^invoicecraft-\d+(?:\.\d+)*$/.test(k)||k==='invoicecraft-2.2.2-simulator')).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const asset=ASSETS.some(path=>new URL(path,self.registration.scope).href===event.request.url);
 if(!asset&&event.request.mode!=='navigate')return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE);
  if(asset){const cached=await cache.match(event.request);if(cached)return cached}
  try{return await fetch(event.request)}catch(error){
   if(event.request.mode==='navigate')return await cache.match('index.html')||Response.error();
   throw error
  }
 })())
});
