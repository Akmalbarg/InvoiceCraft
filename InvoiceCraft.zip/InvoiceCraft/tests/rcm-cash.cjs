// Run with the November 23 backup as the first argument. All writes use simulated storage.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split('rl.createInterface')[0];
const ctx=Function('require','__dirname',harness+';return env')(require,__dirname);
const run=s=>vm.runInContext(s,ctx);
ctx.raw=fs.readFileSync(process.argv[2],'utf8');
let count=0;
function check(label,expression,expected=true){
 const value=JSON.parse(JSON.stringify(run(expression)));
 assert.deepEqual(value,expected,label);
 count++;console.log('PASS',label);
}
run(`var restoreTest=()=>{db=parseBackup(JSON.parse(raw))},month=m=>mcalc('2026-'+m),toPaise=v=>Math.round(v*100);
restoreTest();var oct=db.rcm.find(r=>r.m==='2026-10'),cash=()=>{const c=month('10');return [c.bank,c.external,c.gstPaid,c.gstOutstanding,c.cashBeforeGst,c.cashAfterGst,c.profitInr].map(toPaise)};`);
check('October bank, costs, paid, unpaid, before GST, after payment, accounting profit', 'cash()', [352500,332428,0,34722,20072,20072,-14650]);
check('October paid status changes cash exactly once', "A.ropen({id:oct.id});A.rpaid({v:'1'});A.rsave();cash()",[352500,332428,34722,0,20072,-14650,-14650]);
check('Second save + refresh preserves paid result', "A.ropen({id:oct.id});A.rsave();db=load();cash()",[352500,332428,34722,0,20072,-14650,-14650]);
check('Only the paid flag changed in the real October record', "Object.keys(oct).filter(k=>JSON.stringify(oct[k])!==JSON.stringify(db.rcm.find(r=>r.id===oct.id)[k]))",['paid']);
check('Recorded actual bank credit date is in November', "month('10').bankDates",['2026-11-03']);
check('Unpaid status on reopen releases cash without changing profit',"A.ropen({id:oct.id});A.rpaid({v:'0'});A.rsave();cash()",[352500,332428,0,34722,20072,20072,-14650]);
check('Historical July expense, two-month receipt and bank profit',"var j=month('07');[j.incurred,j.feeSummary.held,j.crossCovered,j.bank,j.profitInr].map(toPaise)",[68400,68400,39200,125041,-24633]);
check('Historical August expense, withheld, card principal, actual charge, GST and profit',"var a=month('08');[a.incurred,a.feeSummary.held,a.feeSummary.card,a.settlements.charges,a.gstInr,a.profitInr].map(toPaise)",[100400,39200,61200,2166,18072,-120638]);
check('Two bank credits counted exactly once across all billing records',"db.rcm.reduce((sum,r)=>sum+toPaise(mcalc(r.m).bank||0),0)",477541);
check('October card debits September, preserving four historical card dates and amounts', "db.rcm.flatMap(r=>(r.cards||[]).map(c=>[c.date,c.allocations[0].month,+c.principal,+c.charge])).sort()",[['2026-06-11','2026-06',957,33.88],['2026-07-02','2026-06',475,16.82],['2026-09-02','2026-08',612,21.66],['2026-10-02','2026-09',2317,82.02]]);
check('October allocation ignores September card expense',"[month('10').feeSummary.card,month('10').feeSummary.charges,month('09').feeSummary.card,month('09').feeSummary.charges]",[0,0,2317,82.02]);
check('Four historical invoice previews match independent whole-rupee AND USD totals',"db.orders.every(o=>{const h=invHtml(o);return h.includes(inrf(Math.round((+o.inrv)/.975-(+o.taxi))))&&h.includes(m(+o.sale + +o.shipFee))})");
check('No unrelated month record changes on paid/unpaid cycle',"JSON.stringify(db.rcm)===JSON.stringify(JSON.parse(raw).rcm)");
check('Actual override stays visible as red accounting loss alongside positive cash', "var html=mledger(month('10'));['Accounting profit after RCM GST liability','net neg','Cash remaining before RCM GST','200.72','347.22'].every(k=>html.includes(k))");
check('Cash with estimated fulfillment is labeled estimated',"delete db.orders[0].printifyInr;rcmCashLines(month('10')).includes('Cash from linked payouts · estimated')");
check('Card reversal redraws entry heading immediately',"restoreTest();A.ropen({id:oct.id});A.addcard();fire('input',{dataset:{owner:'card',index:1,setkey:'refundOf'},value:rd.cards[0].id});document.querySelector('#sh').innerHTML.includes('Card refund 2')");
check('Coverage of order selection toggles without replacing drawer',"A.ropen({id:oct.id});var drawer=document.querySelector('#sh').innerHTML;var summaryNode={};var target={dataset:{pi:'0',order:String(db.orders[0].id)},checked:false,closest:()=>({querySelector:()=>summaryNode})};fire('input',target);!rd.payouts[0].orders.includes(target.dataset.order)&&document.querySelector('#sh').innerHTML===drawer&&summaryNode.textContent==='Orders covered (1)'");
check('Unlinked order can be created edited and deleted through actions',"A.new();Object.assign(dr,{sale:30,item:'QA',date:'2026-12-01'});A.save();var fresh=db.orders.at(-1);A.edit({id:fresh.id});dr.item='QA changed';A.save();var didEdit=db.orders.at(-1).item==='QA changed';A.del({id:fresh.id});didEdit&&!db.orders.some(o=>o.id===fresh.id)");
check('Cross-year payout and next-year card allocate to December',"var dec='2026-12';db.rcm=[{id:3,m:dec,l:100,payouts:[{orders:[],sentDate:'2027-01-04',bankDate:'2027-01-05',feesWithheld:40,reference:'rowA'}],cards:[{id:'b',date:'2027-01-06',principal:60,charge:3,allocations:[{month:dec,amount:60}]}]}];db.orders=[];checkSettlements(db.rcm,S());[mcalc(dec).feeSummary.status,mcalc(dec).settlements.charges]",['Fully Paid',3]);
check('Six-figure ads partially paid by two cards', "db.rcm[0].a=500000;db.rcm[0].cards.push({id:'c',date:'2027-01-12',principal:5000,charge:178,allocations:[{month:dec,amount:5000}]});checkSettlements(db.rcm,S());[mcalc(dec).feeSummary.remaining,mcalc(dec).settlements.charges]",[495000,181]);
check('Distinct withdrawal rates across two payouts and zero profit', "db={orders:[1,2].map(id=>({id,date:'2026-01-01',sale:10,fx:100,printifyInr:id===1?900:950})),rcm:[{id:1,m:'2026-01',inv:'zero',payouts:[90,95].map((rate,i)=>({orders:[String(i+1)],effectiveRate:rate,depositUsd:10,balanceInr:1000,feesWithheld:0}))}],presets:[],settings:{...DS}};var z=mcalc('2026-01');[z.bank,z.profitInr,z.confirmed]",[1850,0,false]);
for(const size of [0,1,10,100,1000]){
 ctx.size=size;
 const start=performance.now();
 check('Order volume '+size,`db={orders:Array.from({length:size},(_,i)=>({id:i+1,date:'2026-01-01',sale:10,fx:100,prod:5})),rcm:[],presets:[],settings:{...DS,conv:0,pay:0}};db=parseBackup(JSON.parse(JSON.stringify(db)));constLedger=mcalc('2026-01');V.rcm();V.orders();[db.orders.length,constLedger.profitInr]`,[size,size*500]);
 console.log('TIMING',size,(performance.now()-start).toFixed(1),'ms');
}
check('Draft preview counts a conflicting invoice month only once; duplicate still blocked on save', "restoreTest();A.ropen({id:db.rcm.find(r=>r.m==='2026-07').id});rd.m='2026-10';var draft=mcalc(rd.m,rd);var blocked=commitR()===0;blocked&&toPaise(draft.gstInr)===18774");
check('Card-only month shows paid GST and card movement independently of profit', "restoreTest();rcmCashLines(month('08')).includes(I(-612-21.66-180.72))");
check('1000 sales and 20 dated payouts settle one ads invoice once', `db.settings={...DS,pay:0,conv:0,gst:0};db.orders=Array.from({length:1000},(_,i)=>({id:i+1,date:'2026-01-01',sale:10,fx:100,printifyInr:500}));
db.rcm=[{id:1,m:'2026-01',a:10000,payouts:Array.from({length:20},(_,i)=>({reference:'bulk-'+i,sentDate:'2026-01-'+String(i+5).padStart(2,'0'),bankDate:'2026-01-'+String(i+6).padStart(2,'0'),orders:db.orders.slice(i*50,(i+1)*50).map(o=>String(o.id)),balanceInr:49500,depositUsd:495,bankCredit:49500,feesWithheld:500}))}];
db=parseBackup(JSON.parse(JSON.stringify(db)));var bulk=mcalc('2026-01');[bulk.n,bulk.bank,bulk.external,bulk.profitInr,bulk.accrual.inr,bulk.feeSummary.remaining,bulk.feeSummary.status]`,[1000,990000,500000,490000,490000,0,'Fully Paid']);
check('Unusually large invalid amount is rejected before restore', "var bad=JSON.parse(raw);bad.orders[0].printifyInr='1e100';try{parseBackup(bad);false}catch{true}");
async function loader(){
 run("var scripts=[];document.createElement=()=>({remove(){}});document.head={appendChild:s=>scripts.push(s)}");
 const p=run("loadJs('test-lib')"),q=run("loadJs('test-lib')");
 assert.equal(p,q);run('scripts[0].onload()');await p;count++;console.log('PASS Concurrent library requests await one load');
 const bad=run("loadJs('retry-lib')");run('scripts[1].onerror()');await assert.rejects(bad);
 const again=run("loadJs('retry-lib')");run('scripts[2].onload()');await again;
 count++;console.log('PASS Failed PDF library loads can be retried');
 console.log(count+' independent cash, history and workflow checks passed');
}
loader().catch(e=>{console.error(e);process.exitCode=1});
