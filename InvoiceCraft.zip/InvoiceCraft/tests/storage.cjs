const vm=require('vm'),fs=require('fs'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8').match(/<script>([\s\S]*)<\/script>/)[1];
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split('vm.createContext(env)')[0];
const store=new Map();let wait=Promise.resolve();
const locks={request(key,work){const result=wait.then(()=>work());wait=result.catch(()=>{});return result}};
const tab=()=>{const c=Function('require','__dirname',harness+';return env')(require,__dirname);c.localStorage={getItem:key=>store.get(key)??null,setItem:(key,v)=>store.set(key,v)};c.navigator.locks=locks;vm.createContext(c);vm.runInContext(source,c);return q=>vm.runInContext(q,c)};
(async()=>{
 const a=tab();await a('writes');const b=tab();await b('writes');
 a("db.orders.push({id:1,date:'2026-01-01',sale:10});save()");
 b("S().shop='concurrent draft';save()");
 await Promise.all([a('writes'),b('writes')]);
 const saved=JSON.parse(store.get('invoicecraft.v1'));
 const results=[
 ['two contexts preserve winning order',saved.orders.length===1],
 ['losing context marks conflict',b('lockedOut')===true],
 ['draft retained for export',b("S().shop")==='concurrent draft'],
 ['conflicting settings did not overwrite disk',saved.settings.shop!=='concurrent draft']
 ];
 fs.writeFileSync(path.join(__dirname,'storage-results.json'),JSON.stringify(results));console.log(results);
 if(results.some(([,v])=>!v))process.exitCode=1
})().catch(e=>{console.error(e);process.exitCode=1});
