"""Run with Python Playwright, system Chromium, Poppler and Tesseract. All figures are synthetic."""
from pathlib import Path
from tempfile import TemporaryDirectory
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from subprocess import check_output
from playwright.sync_api import sync_playwright
import shutil,re
root=Path(__file__).resolve().parents[1]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=root))
Thread(target=server.serve_forever,daemon=True).start()
with TemporaryDirectory() as temp,sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
 page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.goto('http://127.0.0.1:%d/index.html'%server.server_port)
 page.evaluate("async()=>{await navigator.serviceWorker.ready}")
 page.reload();ctx.set_offline(True);page.reload()
 page.locator('[data-a=new]').first.click()
 page.locator('[data-d=date]').fill('2025-03-30')
 page.locator('[data-d=sale]').fill('21.99')
 page.locator('[data-d=shipFee]').fill('5.99')
 page.locator('[data-d=manualRate]').fill('84.12345000')
 page.locator('[data-d=manualPublication]').fill('2025-03-28')
 page.locator('[data-a=save]').click()
 page.wait_for_function("db.orders[0]?.draftValuation?.rate==='84.12345000'")
 page.reload()
 page.evaluate("openEdit(db.orders[0].id)")
 assert page.locator('[data-d=manualRate]').input_value()=='84.12345000'
 page.locator('[data-a=finalize]').click()
 page.wait_for_function("db.orders[0]?.valuation?.inr==='2353.77'")
 page.reload()
 assert page.evaluate("db.orders[0].valuation.publicationDate")== '2025-03-28'
 page.evaluate("A.inv({id:db.orders[0].id})")
 assert page.locator('.sheet .inv').get_by_text('Schedule III',exact=False).count()
 with page.expect_download(timeout=45000) as event:page.locator('[data-a=ipdf]').click()
 pdf=Path(temp)/'invoice.pdf';event.value.save_as(pdf)
 assert re.search(r'Pages:\s+1\b',check_output(['pdfinfo',pdf],text=True))
 check_output(['pdftoppm','-scale-to','2600','-png','-singlefile',pdf,str(Path(temp)/'page')])
 text=check_output(['tesseract',str(Path(temp)/'page.png'),'stdout'],text=True)
 for s in ['FBIL','84.12345000','2353.77','27.98','21.99','5.99','28 Mar 2025','30 Mar 2025','Schedule III','non-publication day']:
  assert s in text,(s,text)
 assert not errors,errors
 print('PASS Offline mobile-width Chromium per-order manual entry, invoice finalization, reload, actual downloaded one-page PDF and rendered invoice content.')
 browser.close()
server.shutdown()
