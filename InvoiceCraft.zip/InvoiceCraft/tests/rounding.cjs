const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('node:assert/strict');
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split('rl.createInterface')[0];
const ctx=Function('require','__dirname',harness+';return env')(require,__dirname);
const calc=q=>vm.runInContext(q,ctx);
const results=[];
function test(name,expected,q){const value=calc(q);assert.deepEqual(JSON.parse(JSON.stringify(value)),expected,name);results.push([name,expected,value])}
calc("db={settings:{...DS,pay:0,conv:0,inr:100,gst:0},orders:[1,2].map(id=>({id,date:'2026-01-01',sale:30,prod:10,fx:100})),presets:[],rcm:[{id:9,m:'2026-01',l:100,payouts:[{orders:['1'],bankCredit:3000,balanceInr:3000,depositUsd:30}]}]};var row=db.rcm[0].payouts[0],rec=db.rcm[0],month=()=>mcalc(rec.m)");
calc("db={settings:{...DS,pay:0,conv:0,inr:100,gst:0,useTds:false,useTcs:false,a_cv:0,a_tx:2,a_pp:2,a_ppf:0,a_rg:0},orders:[{id:1,date:'2026-01-01',sale:10,fees:1.914,fx:100}],rcm:[],presets:[]};var order=db.orders[0],result=()=>calc(order)");
test('single fee rounds before profit',[1.91,8.09,809],'[result().fees,result().net,result().netInr]');
test('monthly pending profit uses cent fee',809,"mcalc('2026-01').profitInr");
test('raw input preserved',1.914,'order.fees');
test('half cent and below cent',[1.92,1.01,0,0.01],'[1.915,1.005,0.004,0.005].map(usdFee)');
test('legacy split fee total',3.82,'Object.assign(order,{sp:true,fl:1.914,fr:1.914,fees:3.828});result().fees');
test('split fee draft to stored total',3.82,'order.fees=splitUsdFees(order,false).rounded;result().fees');
test('split profit',6.18,'result().net');
test('actual card cost applied once',518,'order.printifyInr=100;result().netInr');
test('offsite fraction rounded',1.91,'Object.assign(order,{sale:12.76,offsite:true});S().offsite=15;result().off');
test('automatic converted fees added as cents',[0.19,0.20,0.39],"order={sale:10,tot:10,inrv:999,fees:0};[result().txUsd,result().ppUsd,result().fees]");
fs.writeFileSync(path.join(__dirname,'rounding-results.json'),JSON.stringify(results));console.log(results.length+' rounding checks passed');
