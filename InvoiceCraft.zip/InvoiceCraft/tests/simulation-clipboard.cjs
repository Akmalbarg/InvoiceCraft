const assert=require('node:assert/strict'), fs=require('node:fs'),vm=require('node:vm');
const harness=fs.readFileSync(__dirname+'/vm.cjs','utf8').split('rl.createInterface')[0];
const ctx=Function('require','__dirname',harness+';return env')(require,__dirname);
const run=src=>vm.runInContext(src,ctx);
function check(label,ok){assert.ok(ok,label);console.log('PASS',label)}
(async()=>{
 run("var original=JSON.stringify(db),buffer='';navigator.clipboard={writeText:async value=>{buffer=value}}");
 await run("A.copyfees({target:'editorFeePrompt'})");
 check('Editor copy writes full supplied prompt and confirms success',run("buffer===feePrompt&&document.querySelector('#toast').textContent==='Prompt copied'"));
 run("var picked=false,el=document.querySelector('#editorFeePrompt');el.hidden=true;el.select=()=>{picked=true};navigator.clipboard.writeText=async()=>{throw Error('denied')};document.execCommand=()=>false");
 await run("A.copyfees({target:'editorFeePrompt'})");
 check('Async permission denial reveals selectable prompt in the active sheet',run("picked&&!el.hidden&&document.querySelector('#toast').textContent.includes('selection menu')"));
 check('Successful and failed copies leave the database byte-identical',run("JSON.stringify(db)===original"));
 run("simDraft={...newSim(),name:'Coffee mug',mode:'direct',direct:18};A.simSave();navigator.clipboard.writeText=async v=>{buffer=v}");
 await run("A.simCopy({id:simDraft.id})");
 check('Copy scenario includes estimate and simulation-only label',run("buffer.includes('Coffee mug')&&buffer.includes('Estimated profit')&&buffer.includes('Simulation Only — Not Recorded as a Sale')"));
 run("navigator.clipboard=undefined;var txt=document.querySelector('#simCopyText');txt.hidden=true;txt.select=()=>{picked=true};picked=false");
 await run("A.simCopy({id:simDraft.id})");
 check('Copy scenario offers offline selection fallback',run("picked&&!txt.hidden&&txt.value===buffer"));
})().catch(e=>{console.error(e);process.exitCode=1});
