// Fixed expected rupee amounts are calculated independently of the settlement implementation.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const harness = fs.readFileSync(path.join(__dirname, 'vm.cjs'), 'utf8').split('rl.createInterface')[0];
const ctx = Function('require', '__dirname', harness + ';return env')(require, __dirname);
const run = expression => vm.runInContext(expression, ctx);
let passed = 0;
function check(name, expected, expression) {
  const actual = JSON.parse(JSON.stringify(run(expression)));
  assert.deepEqual(actual, expected, name);
  passed++;
  console.log('PASS', name);
}
run(`
var augMonth='2026-08', sept='2026-09';
var line=(amount,month=augMonth,status='confirmed')=>({amount,month,status});
var payout=(ref,...lines)=>({reference:ref,orders:[],sentDate:'2026-09-15',allocations:lines});
var entry=(reference,kind,...lines)=>({reference,kind,date:'2026-09-16',allocations:lines});
var card=(principal,charge)=>({id:'charge',date:'2026-09-02',principal,charge,allocations:[line(principal)]});
var setup=(fees,sales=0)=>{
 db={settings:{...DS,gst:0,conv:0,pay:0,inr:100},presets:[],orders:[],rcm:[]};
 for(let i=1;i<=sales;i++)db.orders.push({id:i,date:'2026-08-10',sale:30,prod:10,fx:100});
 db.rcm.push({id:1,m:augMonth,l:fees,payouts:[],cards:[],accountEntries:[]});
 return db.rcm[0]
};
var x,info=()=>feeSummary(augMonth,db.rcm),result=()=>{const s=info();return [s.status,s.remaining,s.charges]};
var valid=()=>checkSettlements(db.rcm,S()),fails=f=>{try{f();return false}catch{return true}};
`);
check('Low sales, following-month card, ₹81 real charge', ['Fully Paid',0,81,-2081],
 "x=setup(2000);x.cards=[card(2000,81)];valid();[...result(),mcalc(augMonth).accrual.inr]");
check('Moderate sales, mixed payment', ['Fully Paid',0,0],
 "x=setup(5000,20);x.payouts=[payout('A',line(3500))];x.cards=[card(1500,0)];valid();result()");
check('High sales, 200 orders, no card or bank charge', ['Fully Paid',0,0,0],
 "x=setup(3200,200);x.payouts=[payout('B',line(3200))];valid();[...result(),x.cards.length]");
check('Sufficient sales without evidence', ['Unverified',3200,0], 'x.payouts=[];result()');
check('Confirmed zero after statement review', ['Unpaid',3200,0], 'x.coverageChecked=true;result()');
check('Estimated allocation excluded', ['Unverified',3200,0],
 "x.coverageChecked=false;x.payouts=[payout('E',line(3200,augMonth,'estimated'))];result()");
check('One payout covers two months, another pays the same month', [200,400],
 "x=setup(1000);db.rcm.push({id:2,m:sept,l:600});x.payouts=[payout('p1',line(500),line(200,sept)),payout('p2',line(300))];valid();[info().remaining,feeSummary(sept,db.rcm).remaining]");
check('Unpaid portion stays in original month', 'Partially Paid', 'info().status');
check('Standalone statement deduction and other verified settlement', ['Fully Paid',0,0],
 "x.accountEntries=[entry('balance','account',line(150)),entry('credit','other',line(50))];valid();result()");
check('Reversal reopens the original month', ['Partially Paid',25,0],
 "x.accountEntries.push({...entry('undo','reversal',line(25)),original:'balance'});valid();result()");
check('Excess reversal rejected',true,"x.accountEntries.at(-1).allocations[0].amount=151;var rejected=fails(valid);x.accountEntries.at(-1).allocations[0].amount=25;rejected");
check('Same statement assigned to both payout and standalone rejected',true,
 "x.accountEntries.push(entry(' P1 ','account',line(1)));var rejected=fails(valid);x.accountEntries.pop();rejected");
check('Deleting referenced source rejected',true,"var orig=x.accountEntries.shift();var rejected=fails(valid);x.accountEntries.unshift(orig);rejected");
check('Correction updates net eligible invoice only', ['Fully Paid',0,0],
 "x.l=975;valid();result()");
check('Credit causing excess shows difference and zero unpaid', ['Overpaid / Needs Review',0,-5],
 "x.l=970;[info().status,info().remaining,info().difference]");
check('Preserve verified excess on backup restore', -5,
 "db=parseBackup(JSON.parse(JSON.stringify(db)));info().difference");
check('Settings or unrelated category does not change settlement scope', 970,
 "x=db.rcm[0];x.t=300;S().ov_l=false;S().ov_t=true;info().total");
check('New excess requires explicit review on save',true,
 "A.ropen({id:x.id});rd.l-=1;fails(()=>validateMonthEdit(rd,x.id))");
check('Acknowledged excess can be saved and restored',-6,
 "rd.reviewExcess=true;if(!commitR())throw Error(document.querySelector('#toast').textContent);save();db=load();info().difference");
check('No fee invoice cannot establish remaining balance', ['Unverified',false],
 "x=setup(0);x.settlementOnly=true;[info().status,info().known]");
check('Paise precision, one paise is still due',0.01,
 "x=setup(10.11);x.accountEntries=[entry('p','account',line(10.10))];valid();info().remaining");
check('Payment-only changes preserve billing profit with an actual bank receipt', [1900,1900,1893],
 "x=setup(100,1);x.payouts=[{orders:['1'],balanceInr:2900,depositUsd:29,bankCredit:2900}];var before=mcalc(augMonth).accrual.inr;x.cards=[card(60,0)];var after=mcalc(augMonth).accrual.inr;x.cards[0].charge=7;[before,after,mcalc(augMonth).accrual.inr]");
check('RCM edits and export/import keep standalone allocations', ['Fully Paid',0,7],
 "A.ropen({id:x.id});A.addaccount();var e=rd.accountEntries[0];Object.assign(e,{date:'2026-08-16',reference:'ref-40',allocations:[line(40)]});if(!commitR())throw Error(document.querySelector('#toast').textContent);var blob;dl=(name,data)=>blob=data;A.xjson();fire('change',{dataset:{},id:'imp',files:[blob]});db=load();result()");
check('Separate compact summary and editor field groups',true,
 "V.rcm().includes('Fee and settlement breakdown')&&V.rcm().includes('Fully Paid')&&(A.ropen({id:1}),document.querySelector('#sh').innerHTML.includes('Verified payment-account entries'))");
check('Grouped payout references prevent a duplicate direct deduction',true,
 "x=setup(500);x.payouts=[payout('ded-1,ded-2',line(100))];x.accountEntries=[entry('DED-2','account',line(50))];fails(valid)");
check('Unresolved historical payout cannot overlap new direct evidence',true,
 "x=setup(500);x.payouts=[{orders:[],feesWithheld:100}];A.ropen({id:1});rd.accountEntries=[entry('direct','account',line(50))];fails(()=>validateMonthEdit(rd,1))");
check('Direct settlement is excluded from future automatic payout estimates',0,
 "x=setup(150,1);x.payouts=[{orders:['1'],fromOrders:true}];x.accountEntries=[entry('direct','account',line(150))];payouts(x)[0].computedFeeShare");
console.log(passed + ' new settlement checks passed');
