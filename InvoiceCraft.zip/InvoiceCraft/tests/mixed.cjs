const vm=require('vm'),fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split("rl.createInterface")[0];
const env=Function('require','__dirname',harness+';return env')(require,__dirname);
const run=(q)=>vm.runInContext(q,env);
const results=[];
function check(label,expected,observed){
 const pass=typeof expected==='number'?Math.abs(expected-observed)<1e-6:expected===observed;
 results.push({label,expected,observed,pass});
}
for(const count of [1,2,3,4,12])for(const mode of ['all actual','all estimated','alternating','zero and blank'])for(const status of ['pending','incomplete','settled','cross-month','separate payouts']){
 const orders=[];let actual=0,estimated=0;
 for(let j=0;j<count;j++){
  const estimate=1000+j*10,charge=mode==='zero and blank'?0:1200+j+.25;
  const usesActual=mode==='all actual'||(mode!=='all estimated'&&j%2===0);
  orders.push({id:j+1,date:'2026-01-01',sale:40,prod:estimate/100,fx:100,printifyInr:usesActual?charge:''});
  if(usesActual)actual+=charge;else estimated+=estimate;
 }
 const month=status==='cross-month'?'2026-02':'2026-01';
 const ids=orders.map(o=>String(o.id));
 const payouts=status==='pending'?[]:status==='incomplete'?[{orders:ids,fromOrders:true}]:status==='separate payouts'?orders.map(o=>({orders:[String(o.id)],balanceInr:4000,depositUsd:40,bankCredit:4000})): [{orders:ids,balanceInr:count*4000,depositUsd:40*count,bankCredit:4000*count}];
 env.fixture={orders,month,payouts};run("db={settings:{...DS,conv:0,pay:0},orders:fixture.orders,rcm:[{id:100,m:fixture.month,payouts:fixture.payouts}],presets:[]}");
 const v=run('mcalc(fixture.month)'),name=[count,mode,status].join(' / ');
 check(name+' actual',actual,v.printify.actual);check(name+' estimated',estimated,v.printify.estimated);
 check(name+' total',actual+estimated,v.printify.total);check(name+' net',4000*count-actual-estimated,v.profitInr);
 const n=orders.filter(o=>o.printifyInr!=='').length;
 check(name+' label',n===0?'Estimated':n===count?'Actual':'Mixed (Actual + Estimated)',v.printify.status);
 check(name+' USD order net',orders.reduce((a,o)=>a+40-o.prod,0),run('sum(db.orders).net'));
 check(name+' rendered subtotals',true,run("['Actual Printify costs','Estimated Printify costs','Total Printify costs'].every(label=>mledger(mcalc(fixture.month)).includes(label))"));
 if(status==='cross-month')check(name+' old month balance',0,run("mcalc('2026-01').profitInr"));
}
run("db={settings:{...DS,conv:0,pay:0,mrate:'inr'},presets:[],orders:[1700,'',1600,''].map((v,i)=>({id:i+1,date:'2026-01-01',sale:30,prod:[19,14.5,18,15][i],fx:100,printifyInr:v})),rcm:[{id:8,m:'2026-01',payouts:[{orders:['1','2','3','4'],balanceInr:12000,depositUsd:120,bankCredit:12000}]}]}");
const example=run("mcalc('2026-01')");
check('requested example actual',3300,example.printify.actual);
check('requested example estimated',2950,example.printify.estimated);
check('requested example total',6250,example.printify.total);
check('requested example profit',5750,example.profitInr);
check('requested example linked',6250,example.external);
check('requested example displayed at payout and month',true,run("[mledger(mcalc('2026-01')),payoutEditor(db.rcm[0]),V.rcm()].every(h=>['3,300.00','2,950.00','6,250.00','Mixed (Actual + Estimated)'].every(k=>h.includes(k)))"));
const ids=[1,2,3,4];
for(const val of ['0','1700.25','','1750']){
 env.newValue=val;run("A.edit({id:1});dr.printifyInr=newValue;A.save()");
 check('edit '+JSON.stringify(val),2950+1600+(val===''?1900:Number(val)),run("mcalc('2026-01').printify.total"));
 check('restore '+JSON.stringify(val),true,run("(()=>{let c=mcalc('2026-01');db=parseBackup(JSON.parse(JSON.stringify(db)));return mcalc('2026-01').profitInr===c.profitInr})()"));
}
fs.writeFileSync(path.join(__dirname,'mixed-results.json'),JSON.stringify(results));
console.log(results.length,'checked;',results.filter(v=>!v.pass).length,'failed');
if(results.some(v=>!v.pass))process.exitCode=1;
