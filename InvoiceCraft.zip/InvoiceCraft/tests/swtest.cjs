const vm=require('vm'),fs=require('fs');let listeners={},del=[],work;let list={};
const ctx={self:{addEventListener:(k,f)=>listeners[k]=f,clients:{claim(){}},skipWaiting(){}},caches:{keys:async()=>['unrelated-cache','invoicecraft-1.8','invoicecraft-1.9.6'],delete:async k=>del.push(k),open:async()=>({addAll:async paths=>list.paths=paths})}};
vm.runInNewContext(fs.readFileSync(__dirname+'/../sw.js','utf8'),ctx);
(async()=>{listeners.install({waitUntil:p=>work=p});await work;listeners.activate({waitUntil:p=>work=p});await work;console.log(JSON.stringify({del,assets:list.paths}))})();
