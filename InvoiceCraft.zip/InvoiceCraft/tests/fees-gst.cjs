const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('node:assert/strict');
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split('rl.createInterface')[0];
const ctx=Function('require','__dirname',harness+';return env')(require,__dirname);
const calc=q=>vm.runInContext(q,ctx);
const results=[];
function test(name,expected,q){const value=calc(q);assert.deepEqual(JSON.parse(JSON.stringify(value)),expected,name);results.push([name,expected,value])}
calc("db={settings:{...DS,pay:0,conv:0,inr:100,gst:0},orders:[1,2].map(id=>({id,date:'2026-01-01',sale:30,prod:10,fx:100})),presets:[],rcm:[{id:9,m:'2026-01',l:100,payouts:[{orders:['1'],bankCredit:3000,balanceInr:3000,depositUsd:30}]}]};var row=db.rcm[0].payouts[0],rec=db.rcm[0],month=()=>mcalc(rec.m)");
for(const [withheld,expected] of [[0,3900],[40,3940],[100,4000]]){
 ctx.withheld=withheld;calc('row.feesWithheld=withheld');
 test('statement withholding '+withheld,expected,'month().profitInr');
 test('outside fee '+withheld,100-withheld,'month().extraInr')
}
test('missing coverage preserves upper estimate and shows range',[4000,100],"delete row.feesWithheld;[month().profitInr,month().feeExposure]");
test('pending confirmed allocation excluded from existing cash',[3970,70],"rec.payouts.push({fromOrders:true,orders:['2'],feesWithheld:30});[month().profitInr,month().feeExposure]");
test('two settled payouts and no double deduction',3990,"row.feesWithheld=60;Object.assign(rec.payouts[1],{bankCredit:3000,balanceInr:3000,depositUsd:30});month().profitInr");
test('reject allocation over invoice',true,"(()=>{row.feesWithheld=80;try{checkMonth(rec);return false}catch{return true}})()");
test('reject negative withholding',true,"(()=>{row.feesWithheld=-1;try{checkMonth(rec);return false}catch{return true}})()");
test('restore explicit zero',0,"row.feesWithheld=0;parseBackup(JSON.parse(JSON.stringify(db))).rcm[0].payouts[0].feesWithheld");
test('new estimate incorporates confirmed share once',3900,"rec.payouts=[{fromOrders:true,effectiveRate:100,feesWithheld:40,orders:['1']}];month().profitInr");
test('full invoice GST independent of fee selection',18,"rec.payouts=[];S().gst=18;rec.l=0;rec.t=100;db.orders[0].fees=5;month().gstInr");
test('order GST replaced using order rate',3482,"month().profitInr");
test('paid flag preserves profit',3482,"rec.paid=true;month().profitInr");
test('no invoice retains order GST',3410,"db.rcm=[];mcalc('2026-01').profitInr");
fs.writeFileSync(path.join(__dirname,'fees-gst-results.json'),JSON.stringify(results));console.log(results.length+' fee/GST checks passed');
