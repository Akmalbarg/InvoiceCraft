"""Independent fee and minimum-price oracles. Run with the November 23 backup."""
from decimal import Decimal as D, ROUND_HALF_UP, ROUND_FLOOR
from pathlib import Path
import json, subprocess, sys, hashlib

root=Path(__file__).resolve().parent
proc=subprocess.Popen(['node',str(root/'vm.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def js(code,*args):
    proc.stdin.write(json.dumps([code,*args])+'\n');proc.stdin.flush()
    answer=json.loads(proc.stdout.readline())
    if 'error' in answer: raise ValueError(answer['error'])
    return answer.get('v')
def ck(label,value,expected):
    assert value==expected,(label,value,expected)
    print('PASS',label)
def d(x):return D(str(x))
def q(x,unit='.01'):return x.quantize(D(unit),rounding=ROUND_HALF_UP)
examples=[
    dict(name='T-shirt',brand='Comfort Colors',original='39.99',discount=40,buyerShip='4.99',production=10,shipping='4.25'),
    dict(name='Mug',brand='11 oz ceramic',mode='direct',direct='17.99',production='6.20',shipping='5.50',off='15',tax='1.65'),
    dict(name='Hoodie',brand='Fleece',mode='direct',direct='34.99',qty=2,production='24',shipping='10',off='12',ads='3.00',other=2)]
def oracle(x,unit):
    qty=d(x.get('qty',1));fx=D(95);gross=unit*qty+d(x.get('buyerShip',0));tax=d(x.get('tax',0))
    cv=D('.975') if x.get('convert',True) else D(1)
    paid=(gross+tax)*fx*cv;taxi=q(tax*fx*cv,'1');base=(gross+tax)*fx-taxi
    tx=(base*D('.065')).to_integral_value(rounding=ROUND_FLOOR)
    pp=q(paid*D('.05')+25,'1');reg=q(base*D('.0005'),'1')
    off=min(D(100)*fx,q(base*d(x.get('off',0))/100,'1'))
    fees=sum(q(v/fx) for v in [tx,pp,reg,off])
    listing=d(x.get('events',qty))*D('.2');ads=d(x.get('ads',0))
    payout=(paid-taxi)/fx-fees;pay=max(payout,D(0))*D('.02');gst=(fees+listing+ads)*D('.18')
    cost=(d(x.get('production',0))*qty+d(x.get('shipping',0)))*D('1.035') if 'override' not in x else d(x['override'])/fx
    profit=payout-pay-gst-cost-listing-ads-d(x.get('other',0))
    conversion=(gross+tax)*(1-cv)
    return dict(tx=tx,pp=pp,rg=reg,offI=off,listing=listing,ads=ads,pay=pay,gst=gst,fees=fees+listing+ads+conversion,profit=profit,inr=profit*fx,margin=100*profit/gross)
def ref_price(x,target=0,margin=0):
    for cents in range(0 if d(x.get("buyerShip",0))>0 else 1,25000):
        unit=D(cents)/100;r=oracle(x,unit)
        if r['profit']>=target and r['margin']>=margin:return unit
    raise RuntimeError('reference price out of fixture range')
more=[dict(name='Capped',direct=1000,mode='direct',off='15',convert=False,events=0),dict(name='INR override',direct='20.33',mode='direct',override='1450.60',production=99,shipping=99),dict(name='Zero override',direct=20,mode='direct',override='0',ads=1)]
for x in examples+more:
    unit=d(x['direct']) if x.get('mode')=='direct' else q(d(x['original'])*(1-d(x['discount'])/100))
    actual=js("x=>{let s={...newSim(),...x,fx:95},r=simCalc(s);return {...r.c,...r,breakEven:simSolve(s)?.unit,targetPrice:simSolve(s,5,15)?.unit}}",x)
    ck(x['name']+' sale price',actual['unit'],float(unit))
    for key,val in oracle(x,unit).items():
        ck(x['name']+' '+key,abs(d(actual[key])-val)<D('0.000001'),True)
    ck(x['name']+' break-even vs exhaustive cent search',actual['breakEven'],float(ref_price(x)))
    ck(x['name']+' $5 + 15% target vs exhaustive search',actual['targetPrice'],float(ref_price(x,5,15)))
    if x in examples:print('EXAMPLE',json.dumps([x['name'],float(unit),*[round(actual[k],2) for k in ['fees','gst','profit','inr','margin','breakEven','targetPrice']]]))
backup=Path(sys.argv[1]).read_text()
js("s=>{db=parseBackup(JSON.parse(s));}",backup)
js("""var real=()=>JSON.stringify([db.orders,db.rcm,db.settings,db.presets]),startReal=real(),ledger0=JSON.stringify(mcalc('2026-10')), hist=()=>real()===startReal&&JSON.stringify(mcalc('2026-10'))===ledger0;
A.nav({v:'sim'});var input=(k,v)=>fire('input',{dataset:{sim:k},type:'text',value:v});""")
ck('Simulator tab and accounting isolation label',js("V.sim().includes('Simulation Only — Not Recorded as a Sale')"),True)
ck('Saved settings populate scenarios',js("simRates.every(k=>simDraft[k]===S()[k])"),True)
js("input('original','40');input('discount','40');input('mode','direct');")
ck('First direct price adopts discounted unit price',js('simDraft.direct'),24)
js("input('direct','20');input('mode','discount');")
ck('Changing modes retains both prices',js('[simDraft.original,simDraft.direct,simUnit(simDraft)]'),['40','20',24])
js("simDraft.name='First';A.simSave();var firstId=simDraft.id;A.simDup({id:firstId});simDraft.brand='Mug';A.simSave()")
ck('Distinct saved comparison scenarios',js("db.simulations.length===2&&firstId!==simDraft.id&&V.sim().includes('First copy')"),True)
js("A.simEdit({id:firstId});simDraft.original='50';A.simSave();")
ck('Editing one scenario preserves the other',js('db.simulations.map(s=>s.original)'),['50','40'])
ck('Positive and negative profits styled separately',js("simResults({...newSim(),production:100,direct:5,mode:'direct'}).includes('net neg')"),True)
ck('Target INR conversion matches USD target',js("simResults({...newSim(),target:475,currency:'INR',fx:95})===simResults({...newSim(),target:5,currency:'USD',fx:95})"),True)
ck('Required listing price survives discount rounding',js("simOriginal(24.99,40)===41.65&&simOriginal(24.99,100)===null"),True)
ck('Zero fees and zero margin override saved defaults',js("simCalc({...newSim(),original:20,a_tx:0,a_pp:0,a_ppf:0,a_rg:0,a_cv:0,events:0,pay:0,useGst:false,useTcs:false,useTds:false}).profit"),20)
ck('Reject fractional quantities and invalid rate',js("[-1,0,1.2].every(q=>{try{validateSim({...newSim(),qty:q});return false}catch{return true}})"),True)
ck('Historical backup lacks simulations and restores correctly',js("s=>parseBackup(JSON.parse(s)).simulations===undefined",backup),True)
js("var exported;dl=(n,bytes)=>{exported=bytes};A.xjson();db=parseBackup(JSON.parse(exported));")
ck('JSON export and import retain saved scenarios',js("JSON.stringify(db.simulations)===JSON.stringify(JSON.parse(exported).simulations)"),True)
ck('Reload retains scenarios',js("db=load();db.simulations.length"),2)
js("A.simDelete({id:firstId});")
ck('Scenario deletion isolates each record',js("db.simulations.length===1&&db.simulations[0].id!==firstId"),True)
ck('Scenario actions preserve every financial section and October ledger',js('hist()'),True)
ck('Prompt matches full requested UTF-8 text',hashlib.sha256(js('feePrompt').encode()).hexdigest(),'cd21c8a18566290b2ad93cae86546de890a714d4e4a1a015c5ead10d9d6cdcd0')
ck('Visible RCM home button',js("V.rcm().includes('>Copy CSV Analysis Prompt</button>')"),True)
js("A.ropen({id:db.rcm.find(r=>r.m==='2026-10').id})")
ck('Visible button between monthly fees and payout controls',js("""(()=>{let h=document.querySelector('#sh').innerHTML;return h.indexOf('coverageChecked')<h.indexOf('data-target="editorFeePrompt"')&&h.indexOf('data-target="editorFeePrompt"')<h.indexOf('class="rcm-group rcm-payout"')})()"""),True)
ck('No API call in prompt-copy action',js("!A.copyfees.toString().includes('fetch(')"),True)
ck('Manual copy fallback in sheet shows same complete selectable text',js("""var target=document.querySelector('#editorFeePrompt'), selected=false;target.hidden=true;target.select=()=>{selected=true};document.execCommand=()=>false;navigator.clipboard=undefined;A.copyfees({target:'editorFeePrompt'});selected&&!target.hidden&&document.querySelector('#toast').textContent.includes('selection menu')"""),True)
ck('Prompt workflow preserves historical records',js('hist()'),True)
ck('Narrow-screen simulator single-column rules', '@media(max-width:440px){.simulator .g2{grid-template-columns:1fr}' in (root.parent/'index.html').read_text(),True)
ck('Buyer shipping alone can meet break-even',js("simSolve({...newSim(),buyerShip:20}).unit"),0)
ck('INR reference charge and quote give equal profit for equal total',js("simCalc({...newSim(),original:20,override:900,costSource:'actual'}).profit===simCalc({...newSim(),original:20,override:900,costSource:'quote'}).profit"),True)
proc.stdin.close();proc.wait()
