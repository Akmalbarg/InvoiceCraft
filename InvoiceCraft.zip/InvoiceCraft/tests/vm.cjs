const fs=require('fs'),vm=require('vm'),rl=require('readline');
const file=fs.readFileSync(__dirname+'/../index.html','utf8');
const nodes=new Map(); const listeners={};let storage={};
function el(k){if(!nodes.has(k))nodes.set(k,{style:{setProperty(){}},classList:{toggle(){},add(){},remove(){}},querySelector:sel=>null,scrollIntoView(){},focus(){}});return nodes.get(k)}
const env={localStorage:{getItem:k=>storage[k],setItem:(k,v)=>storage[k]=v},confirm:()=>true,document:{querySelector:el,querySelectorAll:()=>[],body:el('body'),documentElement:el('html'),addEventListener:(k,f)=>listeners[k]=f},navigator:{},location:{protocol:'file:'},setTimeout:()=>0,clearTimeout(){},console,structuredClone};
env.document.querySelector=(k)=>['.sb','.sb,el'].includes(k)?null:el(k);
env.FileReader=class{readAsText(f){this.result=f;this.onload()}};
env.fire=(k,t)=>listeners[k]({target:t});
vm.createContext(env);vm.runInContext(file.match(/<script>([\s\S]*)<\/script>/)[1],env);
rl.createInterface({input:process.stdin}).on('line',l=>{try{const [q,x]=JSON.parse(l);env.arg=x;let v=vm.runInContext(x===undefined?(q.startsWith('()=>')?'('+q+')()':q):'('+q+')(arg)',env);process.stdout.write(JSON.stringify({v})+'\n')}catch(e){process.stdout.write(JSON.stringify({error:String(e)})+'\n')}});
