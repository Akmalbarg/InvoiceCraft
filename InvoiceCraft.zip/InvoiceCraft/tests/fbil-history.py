"""Compare the backup and rendered documents across two builds. Inputs stay local."""
import json, subprocess, sys
from pathlib import Path
fixture=Path(sys.argv[1]);old=Path(sys.argv[2]);new=Path(__file__).resolve().parents[1]
raw=json.loads(fixture.read_text())
def extract(app):
    queries=[["b=>{db=parseBackup(b);return true}",raw],["[db.orders,db.rcm,db.orders.map(invHtml),db.rcm.filter(r=>!r.settlementOnly).map(rinvHtml)]"]]
    output=subprocess.run(['node',app/'tests/vm.cjs'],input=''.join(json.dumps(q)+'\n' for q in queries),capture_output=True,text=True,check=True)
    return json.loads(output.stdout.splitlines()[1])['v']
before,after=map(extract,[old,new])
assert after==before
assert after[:2]==[raw['orders'],raw['rcm']]
print('PASS historical order and monthly records, commercial invoice HTML, and RCM documents match.')
