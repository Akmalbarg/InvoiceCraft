const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const XLSX = require('../lib/xlsx.full.min.js');
const harness = fs.readFileSync(__dirname+'/vm.cjs','utf8').split('rl.createInterface')[0];
const ctx = Function('require','__dirname',harness+';return env')(require,__dirname);
ctx.XLSX = XLSX;
vm.runInContext('loadJs=async()=>{};toast=msg=>{throw Error(msg)}',ctx);

async function importFile(name,bytes){
 ctx.input={files:[new File([bytes],name)],value:'selected'};
 vm.runInContext('db.fbil=emptyRegister()',ctx);
 await vm.runInContext('importRateFile(input)',ctx);
 assert.deepEqual(JSON.parse(vm.runInContext('JSON.stringify(db.fbil.rates)',ctx)),[{date:'2025-03-28',rate:'84.12345000'}]);
 assert.equal(ctx.input.value,'');
}
(async()=>{
 await importFile('rates.csv','date,rate\r\n2025-03-28,84.12345000');
 const sheet=XLSX.utils.aoa_to_sheet([['Reference Rate Archive'],['Date','1 GBP','1 USD'],[45744,111.25,84.12345]]);
 sheet.A3.z='dd/mm/yyyy';sheet.C3.z='0.00000000';
 const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,sheet,'Rates');
 await importFile('rbi.xls',XLSX.write(book,{type:'buffer',bookType:'biff8'}));
 await importFile('web-export.xls','<html><table><tr><td>Date</td><td>1 USD</td></tr><tr><td>28/03/2025</td><td>84.12345000</td></tr></table></html>');
 console.log('PASS CSV, binary Excel and HTML-table XLS imports through the file handler');
})().catch(error=>{console.error(error);process.exitCode=1});
