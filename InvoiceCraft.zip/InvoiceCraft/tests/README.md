Run `python simulator.py BACKUP.json` and `node simulation-clipboard.cjs` for the simulator and prompt checks. The latest assertion index is results-2.2.2-simulator.csv.

## Version 2.2.2

Run `python payoneer.py PATH_TO_NOVEMBER_23_BACKUP.json` for the independent Decimal calculations, payout editing, backup round trip, and October regression. Open Audit-2.2.2.html and results-2.2.2.csv for the release run.

## Version 2.2.1

Open Audit-2.2.1.html in the application folder for the November 23 audit. results-2.2.1.csv contains the per-assertion results. With Node 24 run rcm-cash.cjs and actions-offline.cjs with the November 23 four-order JSON as an argument. The current financial.py and settlement.cjs suites also accept the November 22 four-order fixture. The statement audit requires June, July, August, October and November CSVs. Original comparison results retain their older expectations. No business backup is bundled.

Run with Node 24 and Python 3.12 from any directory. Use node mixed.cjs and node storage.cjs for synthetic tests. Run python financial.py PATH_TO_ORIGINAL_AUDITED_BACKUP.json for the original audit cases with revised expectations. The suite writes its local JSON outputs next to the scripts. The original-regression.py file preserves the legacy expectations for comparison. The financial suite uses the November 22 audit fixture; an unrelated backup will not have the same expected dollar amounts. No business backup is included. See results.csv for this release run.

Run node fees-gst.cjs for explicit, unknown and partial withholding, and invoice-GST replacement.

Run node rounding.cjs for USD cent rounding and profit checks.

Run node tax-check.cjs. Run node settlement.cjs PATH_TO_UPDATED_FOUR_ORDER_BACKUP.json and python statements.py DIRECTORY_WITH_JUNE_JULY_AUGUST_OCTOBER_CSV_FILES for the settlement evidence checks. The ZIP excludes the source business records.

## Version 2.2.0 settlement tests

Run `node monthly-settlements.cjs` for the 27 settlement, evidence, profit and persistence checks. All 27 and the 50 historical settlement checks passed. The 734 mixed regressions, 17 fee/GST checks, 21 sales-tax checks and 10 rounding checks passed. Four storage conflict checks and five simulated offline cache and navigation checks passed. Responsive field and checkbox rules were checked statically. Live mobile rendering and a physical offline refresh were not verified.

With the supplied November 22 backup the broader financial suite passed 1,469 of 1,474 assertions in both versions 2.1.2 and 2.2.0. The five existing mismatches concern two July expectations, malformed Printify data on restore, a cross-month order expectation and a Monthly KPI expectation.

## Version 3.0.0

Open Audit-3.0.0.html for executed results and the outstanding browser download check. Run `node tests/fbil.cjs` from the app root for the FBIL and accounting cases. For the historical fixture comparison run `python tests/fbil-history.py BACKUP.json PATH_TO_2.2.2_APP`. Run `python tests/fbil-browser.py` for the mobile-width Chromium offline and invoice-download check. It requires Python Playwright, system Chromium, Poppler and Tesseract. All FBIL test rates and closures are synthetic.
