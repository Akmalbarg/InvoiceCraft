// Action dispatch and file generation with simulated browser peripherals.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const app=path.join(__dirname,'..');
const harness=fs.readFileSync(path.join(__dirname,'vm.cjs'),'utf8').split('rl.createInterface')[0];
const ctx=Function('require','__dirname',harness+";env.press=d=>listeners.click({stopPropagation(){},target:{closest:()=>({dataset:d})}});return env")(require,__dirname);
const run=code=>vm.runInContext(code,ctx);
let count=0;
function check(label,condition){assert.ok(condition,label);count++;console.log('PASS',label)}
ctx.raw=fs.readFileSync(process.argv[2],'utf8');
run("db=parseBackup(JSON.parse(raw)); var first=db.orders[0],record=db.rcm[0],click=(a,fields={})=>press({a,...fields});");
for(const view of ['dash','orders','presets','rcm','set']){
 ctx.view=view;check('Navigate '+view,run("click('nav',{v:view});ui.view===view&&document.querySelector('#app').innerHTML.includes('<h1>')"))
}
check('Range filter',run("click('range',{v:'7'});ui.range==7"));
check('Order loss filter',run("click('flt',{v:'loss'});ui.flt==='loss'"));
check('Order detail',run("click('open',{id:first.id});ui.sheet.t==='view'"));
check('Open, edit, offsite toggle and close',run("click('edit',{id:first.id});click('off',{v:'0'});var off=!dr.offsite;click('close');off&&ui.sheet===null"));
check('Open by billing month',run("click('mopen',{mo:'2026-10'});rd.m==='2026-10'"));
check('Add and remove standalone evidence',run("click('addaccount');click('dropaccount',{index:0});rd.accountEntries.length===0"));
check('Add and remove a card billing allocation through buttons',run("click('addline',{owner:'card',index:0});var added=rd.cards[0].allocations.length===2;click('dropline',{owner:'card',index:0,line:1});added&&rd.cards[0].allocations.length===1"));
check('Open and cancel preset edit',run("click('pedit',{i:0});click('pcancel');ui.pe===null"));
check('Card input and payout actions exist in drawer',run("click('ropen',{id:record.id});var drawer=document.querySelector('#sh').innerHTML;['addcard','dropcard','addline','pplus','pminus','rpaid','rsave','rgen','rdel'].every(k=>drawer.includes('data-a='+k))"));
for(const [action,id] of [['logo','lg'],['sign','sg'],['ximp','imp']]){
 ctx.key=id;ctx.action=action;check('File picker dispatch '+action,run("var hit=false;document.querySelector('#'+key).click=()=>hit=true;click(action);hit"));
}
check('Clear seller logo and signature',run("S().inv_logo=S().inv_sign='temporary';click('logoclr');click('signclr');!S().inv_logo&&!S().inv_sign"));
check('Recovery export sends stored bytes to download',run("var exported;dl=(name,txt)=>exported={name,txt};localStorage.setItem(K+'.before-restore',raw);click('recoveryExport');exported.txt===raw"));
check('All literal action names have handlers',(()=>{const src=fs.readFileSync(path.join(app,'index.html'),'utf8');const handlers=run('Object.keys(A)');return [...src.matchAll(/data-a=["']?([a-z][a-zA-Z]+)(?=[\s>"'])/g)].every(m=>handlers.includes(m[1]))})());
const keys=(html,attr)=>[...new Set([...html.matchAll(new RegExp('data-'+attr+'=["\x27]?([a-zA-Z0-9_]+)','g'))].map(m=>m[1]))];
run("click('edit',{id:first.id});");
let orderHtml=run("document.querySelector('#sh').innerHTML");
run("click('split')");orderHtml+=run("document.querySelector('#sh').innerHTML");
for(const field of keys(orderHtml,'d')){
 ctx.field=field;
 check('Order field input '+field,run("fire('input',{dataset:{d:field},value:'1'});dr[field]==='1'"));
}
run("click('ropen',{id:record.id})");
const monthHtml=run("document.querySelector('#sh').innerHTML");
for(const field of keys(monthHtml,'r')){
 ctx.field=field;
 check('RCM field input '+field,run("var flag=['coverageChecked','settlementOnly','reviewExcess'].includes(field);var value=field==='m'?'2026-10':field.endsWith('date')?'2026-11-03':'1';fire('input',{dataset:{r:field},type:flag?'checkbox':'text',checked:true,value});rd[field]===(flag?true:value)"));
}
run("click('ropen',{id:record.id})");
for(const field of keys(monthHtml,'pkey')){
 ctx.field=field;
 check('Payout field input '+field,run("var value=field.endsWith('Date')?'2026-11-04':'1';fire('input',{dataset:{pi:'0',pkey:field},value});rd.payouts[0][field]===value"));
}
let revoked=0;
ctx.URL={createObjectURL:()=>'test-file',revokeObjectURL:()=>revoked++};
ctx.Image=class{set src(v){this.onerror()}};
check('Unreadable logo reports failure and releases preview URL',run("var logo=S().inv_logo;fire('change',{dataset:{},id:'lg',files:[{}]});document.querySelector('#toast').textContent.includes('Image could not be read')&&S().inv_logo===logo")&&revoked===1);
ctx.FileReader=class{readAsText(){this.onerror()}};
check('Unreadable backup preserves current records',run("var keep=JSON.stringify(db);fire('change',{dataset:{},id:'imp',files:[{}]});document.querySelector('#toast').textContent.includes('could not be read')&&JSON.stringify(db)===keep"));

let prints=0;
ctx.window={print:()=>prints++};ctx.addEventListener=()=>{};ctx.removeEventListener=()=>{};
ctx.document.createElement=()=>({style:{},offsetHeight:100,querySelectorAll(){return Array.from({length:(this.innerHTML.match(/<div class=(?:"inv pb"|inv)>/g)||[]).length},()=>({offsetHeight:100}))},remove(){}});
ctx.document.body.appendChild=()=>{};
for(const [name,id,content] of [['iprint','first.id','COMMERCIAL'],['rprint','record.id','PAYMENT VOUCHER'],['print','first.id','Profit']]){
 const n=prints;check('Print dispatch '+name,run("click('"+name+"',{id:"+id+"});document.querySelector('#pr').innerHTML.toLowerCase().includes('"+content.toLowerCase()+"')")&&prints===n+1);
}
async function pdfChecks(){
 const J=require(path.join(app,'lib','jspdf.umd.min.js')).jsPDF;
 const image='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigD//2Q==';
 ctx.html2canvas=async()=>({width:720,height:1000,toDataURL:()=>image});
 ctx.document.head={appendChild(s){queueMicrotask(()=>s.onload())}};
 let completed;ctx.window.jspdf={jsPDF:function(options){const doc=new J(options);doc.save=name=>completed({name,bytes:Buffer.from(doc.output('arraybuffer'))});return doc}};
 for(const [action,id,pages] of [['ipdf','first.id',1],['rpdf','record.id',2]]){
  const result=new Promise((resolve,reject)=>{completed=resolve;const t=setTimeout(()=>reject(Error('PDF timed out')),2000);t.unref()});
  run("click('"+action+"',{id:"+id+"})");const {bytes,name}=await result;
  const contents=bytes.toString('latin1');check('PDF generation '+action,contents.startsWith('%PDF-')&&name.endsWith('.pdf')&&(contents.match(/\/Type \/Page\b/g)||[]).length===pages);
 }
}
async function offline(){
 const base='https://invoicecraft.test/',objects=new Map(),events={},deleted=[];
 const cache={async addAll(urls){for(const u of urls)objects.set(new URL(u,base).href,fs.readFileSync(path.join(app,u==='./'?'index.html':u)))},async match(u){return objects.get(new URL(u.url||u,base).href)}};
 const browser={self:{registration:{scope:base},addEventListener:(n,f)=>events[n]=f,skipWaiting(){},clients:{claim(){}}},caches:{open:async()=>cache,keys:async()=>['invoicecraft-2.2.0','other-app','invoicecraft-2-custom-assets'],delete:async k=>deleted.push(k)},URL,fetch:async()=>{throw Error('offline')}};
 vm.runInNewContext(fs.readFileSync(path.join(app,'sw.js'),'utf8'),browser);
 let work;await events.install({waitUntil:p=>work=p});await work;
 check('All precache assets exist',objects.size===13&&objects.has(new URL('Audit-3.0.0.html',base).href));
 events.activate({waitUntil:p=>work=p});await work;check('Only old app cache removed',deleted.join(',')==='invoicecraft-2.2.0');
 let intercepted=false;
 events.fetch({request:{url:base+'private.png',method:'GET',mode:'cors'},respondWith:()=>intercepted=true});
 check('Unknown subresource does not receive offline HTML',!intercepted);
 for(const u of ['index.html','guide.html','lib/jspdf.umd.min.js','lib/html2canvas.min.js','fallback']){
  events.fetch({request:{url:base+u,method:'GET',mode:'navigate'},respondWith:p=>work=p});
  const bytes=await work;check('Offline '+u,u==='fallback'?bytes.equals(objects.get(base+'index.html')):bytes.length>0)
 }
}
(async()=>{await pdfChecks();await offline();console.log(count+' action and offline checks passed')})().catch(e=>{console.error(e);process.exitCode=1});
