import json,glob,pathlib,math,threading,http.server,functools,os
from decimal import Decimal as D,ROUND_HALF_UP,ROUND_FLOOR

from pathlib import Path
root=Path(__file__).resolve().parent
src=root.parent
import sys
backup=Path(sys.argv[1])
data=json.loads(backup.read_text())
import subprocess
proc=subprocess.Popen(['node',str(root/'vm.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def ev(q,*args):
 proc.stdin.write(json.dumps([q,*args])+'\n');proc.stdin.flush();v=json.loads(proc.stdout.readline())
 if 'error' in v:raise Exception(v['error'])
 return v.get('v')
results=[]
def ck(group,label,e,a):
 ok= math.isclose(e,a,abs_tol=0.000001,rel_tol=1e-11) if type(e) in (int,float) and type(a) in (int,float) else e==a
 results.append([group,label,e,a,'PASS' if ok else 'FAIL'])
def restore():
 ev("s=>fire('change',{dataset:{},id:'imp',files:[s]})",backup.read_text())
restore()
ck('Import','4 sections exact after import',True,ev('db',)=={k:data[k] for k in ('orders','rcm','presets','settings')})
def d(x):return D(str(x or 0))
def fee(x):return x.quantize(D(1),rounding=ROUND_HALF_UP)
def ref(o,s):
 sale,shipping,prod,act,paid,total,manual,tax=[d(o.get(k)) for k in ('sale','shipFee','prod','actShip','inrv','tot','fees','taxi')]
 gross=sale+shipping
 pre=paid/(1-d(s['a_cv'])/100)
 auto=paid>0 and gross>0 and (total>=gross or (o.get('taxi') not in ('',None) and pre>tax))
 rate=pre/total if auto and total>=gross else (pre-tax)/gross if auto else paid/gross if paid and gross else d(o.get('fx') or s['inr'])
 if auto and o.get('taxi') in ('',None):tax=(total-gross)*rate
 base=pre-tax
 tx=(d(s['a_tx'])*base/100).to_integral_value(rounding=ROUND_FLOOR) if auto else D(0)
 pp=fee(d(s['a_pp'])*paid/100+d(s['a_ppf'])) if auto else D(0)
 rg=fee(d(s['a_rg'])*base/100) if auto else D(0)
 offbase=base if s['offShip'] else sale*rate
 offI=fee(offbase*d(s['offsite'])/100) if auto and o.get('offsite') else D(0)
 off=offI/rate if auto else ((gross if s['offShip'] else sale)*d(s['offsite'])/100 if o.get('offsite') else D(0))
 fees=manual+(tx+pp+rg)/rate
 payout=((paid-tax)/rate if auto else gross)-fees-off
 pay=payout*d(s['pay'])/100;conv=(act+prod)*d(s['conv'])/100
 tds=gross*d(s['tds'])/100 if s['useTds'] else D(0);tcs=gross*d(s['tcs'])/100 if s['useTcs'] else D(0);gst=(off+fees)*d(s['gst'])/100 if s['useGst'] else D(0)
 net=payout-pay-conv-act-prod-tds-tcs-gst
 cost=(act+prod+conv)*rate if o.get('printifyInr') in ('',None) else d(o['printifyInr'])
 ni=(payout-pay-tds-tcs-gst)*rate-cost
 return {k:float(v) for k,v in dict(gross=gross,ship=act,prod=prod,tx=tx,pp=pp,rg=rg,offI=offI,fees=fees,off=off,payout=payout,pay=pay,conv=conv,tds=tds,tcs=tcs,gst=gst,net=net,netInr=ni,printifyCostInr=cost,rate=rate,mg=net/gross*100 if gross else 0).items()}
refs=[ref(o,data['settings']) for o in data['orders']]
actual=ev('db.orders.map(calc)')
for o,ex,ac in zip(data['orders'],refs,actual):
 for k,v in ex.items():ck('Real orders',o['inv']+' '+k,v,ac[k])
months=sorted({o['date'][:7] for o in data['orders']}|{r['m'] for r in data['rcm']})
monthly=ev('ms=>ms.map(m=>mcalc(m))',months);summary=[]
for mo,ac in zip(months,monthly):
 os_=[v for o,v in zip(data['orders'],refs) if o['date'].startswith(mo)]
 r=next((r for r in data['rcm'] if r['m']==mo),{})
 sub=sum(r.get(k,0) for k in 'ltra pogx'.replace(' ',''));extra=sum(r.get(k,0) for k in 'lrax');gst=sub*.18
 legacy=sum(x['netInr'] for x in os_)-extra-extra*.18
 full=sum(x['netInr']+x['gst']*x['rate'] for x in os_)-extra-gst if r else legacy
 if r.get('payouts'):full=legacy=3525-sum(x['printifyCostInr'] for x in os_)-gst
 ck('Real months',mo+' implemented estimate or settlement',legacy,ac['profitInr'])
 ck('Invoice replacement',mo+' single invoice GST basis',full,ac['profitInr'])
 summary.append(dict(month=mo,sub=sub,extra=extra,gst=gst,expected=full,actual=ac['profitInr'],basis=legacy,**{k:ac.get(k) for k in ['bank','netRate','receiptRate','external','profit','gstInr','extraInr','ordInr']}))
 if r:ck('Invoice GST',mo,gst,ev('r=>rc(r).gst',r))
(root/'numbers.json').write_text(json.dumps(dict(refs=refs,actual=actual,summary=summary),indent=2))
# Synthetic exact decimal matrix; independent per-case order and month expectations.
s=dict(data['settings'])
fixtures=[]
for mask in range(64):
 o=dict(sale=23.99,shipFee=5.99,actShip=4.75,prod=11.75,inrv='3046' if mask&1 else '',tot='32.90' if mask&2 else '',taxi='270' if mask&4 else '',offsite=bool(mask&8),fees=.19,date='2026-10-01',id=1)
 ss=dict(s,offShip=bool(mask&16),useTds=bool(mask&32),useTcs=bool(mask&32))
 fixtures.append((o,ss))
cases=ev('xs=>{const prev=db.settings;try{return xs.map(([o,s])=>{db.settings=s;return calc(o)})}finally{db.settings=prev}}',fixtures)
for i,((o,ss),c) in enumerate(zip(fixtures,cases)):
 e=ref(o,ss);ck('Order matrix',str(i),True,all(math.isclose(c[k],v,abs_tol=1e-8) for k,v in e.items()))
# 8 categories x 2 order GST treatments. Separate invoice and incremental profit.
vals=[1,2,4,8,16,32,64,128]
matrix=ev("""()=>{let original=db;let out=[];try{for(let mask=0;mask<256;mask++)for(let use of [false,true]){let r={id:1,m:'2026-01'};db={orders:[],rcm:[r],settings:{...DS,useGst:use},presets:[]};RF.forEach(([k],i)=>{r[k]=2**i;S()['ov_'+k]=!!(mask&(1<<i))});const c=mcalc(r.m);out.push([c.extraInr,c.gstInr,rc(r).gst,c.profitInr])}}finally{db=original}return out}""")
for i,(extra,inc,gst,pf) in enumerate(matrix):
 mask=i//2;ck('Fee masks',str(i),True,extra==mask and abs(gst-45.9)<1e-8 and abs(inc-(mask if i%2 else 255)*.18)<1e-8 and abs(pf+mask+inc)<1e-8)
# Full status and cost matrix with documented fixed-value order estimates; pending gross 3000 per order.
scenarios=ev("""()=>{const old=db;const out=[];try{for(let status of ['none','draft','actual','estimated','mixed','cross'])for(let a of ['',1700,0])for(let b of ['',1455.75,0])for(let paid of [false,true]){let o=[{id:1,date:'2026-01-02',sale:30,prod:16.5,fx:100,printifyInr:a},{id:2,date:'2026-01-03',sale:30,prod:14.5,fx:100,printifyInr:b}];let r={id:4,m:status==='cross'?'2026-02':'2026-01',l:100,paid,payouts:[]};let row={fromOrders:true,orders:['1','2'],balanceInr:5900,depositUsd:59};if(status!=='none')r.payouts.push(row);if(['actual','cross','mixed'].includes(status))row.bankCredit=5800;if(status==='estimated')row.effectiveRate=98;if(status==='mixed'){row.orders=['1'];row.bankCredit=2800;r.payouts.push({fromOrders:true,orders:['2']})}db={orders:o,rcm:[r],settings:{...DS,conv:0,pay:0},presets:[]};const c=mcalc(r.m);out.push([status,a,b,paid,c.profitInr,c.printifySource,c.external??null,calc(o[0]).net,c.pendingCount??null,mcalc('2026-01').profitInr])}}finally{db=old}return out}""")
for status,a,b,paid,pf,lab,ext,usd,pending,jan in scenarios:
 cost=(1650 if a=='' else a)+(1450 if b=='' else b)
 income={'none':5900,'draft':5900,'actual':5800,'cross':5800,'estimated':59*98,'mixed':5800}[status]
 count=int(a!='')+int(b!='');label=['Estimated','1 Actual · 1 Estimated','Actual'][count]
 ck('Printify/payout matrix',str([status,a,b,paid]),True,abs(pf-(income-cost-18))<.000001 and lab==label and usd==13.5 and (status!='cross' or jan==0) and (status not in ('actual','cross','estimated') or abs(ext-cost)<.000001))
def report():
 (root/'tests.json').write_text(json.dumps(results,indent=1));print('COUNT',len(results),'FAIL',[(x[0],x[1],x[2:4]) for x in results if x[-1]!='PASS'][-40:],flush=True)
report()
def check(label,expected,js,group='Behavior'):
 try: actual=ev(js)
 except Exception as e:actual='Exception '+str(e)
 ck(group,label,expected,actual)
def init():ev("()=>{ui.sheet=null;ui.view='orders';db={orders:[],rcm:[],presets:[],settings:{...DS,inr:100,conv:0,pay:0}};save()}")
def base():init();ev("()=>{db.orders=[{id:1,date:'2026-01-10',sale:30,prod:10,fx:100},{id:2,date:'2026-01-11',sale:30,prod:10,fx:100}];db.rcm=[{id:3,m:'2026-01',payouts:[]}]}")
def openr():ev("()=>A.ropen({id:3})")
def order():ev("()=>{A.new();Object.assign(dr,{sale:30,prod:16.5,actShip:0,shipFee:0,date:'2026-01-10',fx:100});A.save()}")
init();order()
for val in ['1700','1780.55','0','999999999.99','','-1','abc']:
 check('edit actual '+repr(val),True,"""()=>{const id=db.orders[0].id;A.edit({id});dr.printifyInr="""+json.dumps(val)+""";A.save();const o=db.orders[0],c=calc(o);return """+("!!ui.sheet && !c.actualPrintify" if val in ('-1','abc') else "ui.sheet===null && Math.abs(c.netInr-(3000-"+str(float(val) if val else 1650)+"))<1e-6 && c.net===13.5")+"""}""")
check('Duplicate clears bank charge',True,"()=>{A.dup({id:db.orders[0].id});return dr.printifyInr===''}")
base();openr()
check('dates reject reverse bank sequence',0,"()=>{A.pplus();Object.assign(rd.payouts[0],{sentDate:'2026-02-02',bankDate:'2026-02-01'});return commitR()}")
check('cross-month dates accepted',True,"()=>{rd.payouts[0].bankDate='2026-02-03';return !!commitR()}")
check('future order rejected',0,"()=>{Object.assign(rd.payouts[0],{orders:['1'],sentDate:'2026-01-01',bankCredit:3000});return commitR()}")
base();openr()
check('payout cancel isolates draft',0,"()=>{A.pplus();rd.payouts[0].orders.push('1');A.close();return db.rcm[0].payouts.length}")
check('pending order estimate kept',4000,"()=>{db.rcm[0].payouts=[{orders:['1'],fromOrders:true}];return mcalc('2026-01').profitInr}")
check('incomplete reservation available elsewhere',True,"()=>{return !payoutEditor({m:'2026-02',payouts:[{orders:[],fromOrders:true}]}).includes('display:none')}")
check('removed payout frees link',True,"()=>{A.ropen({id:3});A.pminus();commitR();return !payoutEditor({payouts:[{orders:[]}]}).includes('display:none')}")
base()
check('unlinked actual payout avoids double proceeds',4000,"()=>{db.rcm[0].payouts=[{balanceInr:3000,depositUsd:30,bankCredit:3000,orders:[]}];return mcalc('2026-01').profitInr}")
base()
check('explicit zero settlement stays zero',0,"()=>{db.rcm[0].payouts=[{fromOrders:true,orders:['1'],balanceInr:'0',depositUsd:30,bankCredit:3000}];return payouts(db.rcm[0])[0].balanceInr}")
base()
check('deleting linked order preserves expense or prevents delete',4000,"()=>{db.rcm[0].payouts=[{orders:['1','2'],balanceInr:6000,depositUsd:60,bankCredit:6000}];A.del({id:1});return mcalc('2026-01').profitInr}")
base()
check('unsettled fees in later payout still included',3900,"()=>{db.rcm[0].l=100;db.rcm[0].payouts=[{orders:['1'],balanceInr:3000,depositUsd:30,bankCredit:3000},{orders:['2'],fromOrders:true}];S().gst=0;return mcalc('2026-01').profitInr}")
base()
check('different-rate two payouts',3900,"()=>{db.rcm[0].payouts=[{orders:['1'],balanceInr:3000,depositUsd:30,bankCredit:3000},{orders:['2'],balanceInr:3000,depositUsd:30,effectiveRate:2900/30}];return mcalc('2026-01').profitInr}")
check('editing second preserves first',3800,"()=>{db.rcm[0].payouts[1].bankCredit=2800;return mcalc('2026-01').profitInr}")
check('USD equivalent of actual net at 100',18,"()=>{db.orders[0].printifyInr=3000;return mcalc('2026-01').profit}")
base()
check('duplicate month refused',0,"()=>{A.rnew();rd.m='2026-01';return commitR()}")
check('duplicate manual self-invoice refused',0,"()=>{db.rcm[0].rno='SELF-1';A.rnew();Object.assign(rd,{m:'2026-02',rno:'SELF-1'});return commitR()?1:0}")
init();order()
check('split fees survive switching back',4,"()=>{A.edit({id:db.orders[0].id});dr.sp=true;dr.ft=4;dr.fees=1;A.split();return Number(oFromDr().fees)}")
check('invalid auto input retains manual fee lines',4,"()=>{Object.assign(dr,{sp:true,ft:4,fees:4,inrv:300,tot:1,taxi:''});return calc(oFromDr()).fees}")
check('blank date rejected',True,"()=>{dr.date='';A.save();return !!ui.sheet}")
base()
check('negative payout incurs zero estimated withdrawal fee',0,"()=>{S().pay=2;return calc({sale:5,fees:10}).pay}")
check('no tax data avoids automatic fees',False,"()=>calc({sale:10,inrv:900}).au")
check('automatic rate with explicit zero tax',100,"()=>calc({sale:10,inrv:975,taxi:0}).rate")
restore()
check('historical October profit unchanged after new conversion default',actual[1]['netInr'],"()=>{S().a_cv=3;return calc(db.orders[1]).netInr}")
restore()
check('issued October GST after settings rate change',347.22,"()=>{S().gst=12;return rc(db.rcm[0]).gst}")
restore()
check('dashboard breakup has finite data',False,"()=>{ui.range=0;return V.dash().includes('NaN')}")
check('dashboard includes conversion row',True,"()=>V.dash().includes('Etsy currency conversion')")
check('total RCM KPI equals sum of invoices',sum(r['gst'] for r in summary),"()=>db.rcm.reduce((a,r)=>a+mcalc(r.m).gstInr,0)")
check('paid flag changes liability status only',True,"()=>{let r=db.rcm[0],v=mcalc(r.m);r.paid=true;let w=mcalc(r.m);return v.profitInr===w.profitInr && v.pend && !w.pend}")
check('monthly INR-only display omits USD',True,"()=>!mledger(mcalc('2026-10')).includes('$')")
restore()
for v in ['dash','orders','rcm','presets','set']:
 check(v+' view renders',True,"()=>V."+v+"().includes('<h1>')",'Views')
check('order search',1,"()=>{ui.q='4217450000';return (V.list().match(/data-a=open/g)||[]).length}")
check('preset search finds hidden end entry',True,"()=>{ui.pq=db.presets.at(-1).n;return V.plist().includes(E(ui.pq))}")
check('guide route',True,"()=>V.set().includes('guide.html')")
check('commercial number generated on first preview',True,"()=>{db.orders[0].inv='';A.inv({id:db.orders[0].id});return !!db.orders[0].inv}")
check('commercial invoice contains saved total HSN and quantity',True,"()=>{let o=db.orders[1];return [o.inv,o.hsn,'$29.98',inrf(29.98*calc(o).rate)].every(x=>invHtml(o).includes(x))}")
check('RCM doc two printable sheets and all fee codes',True,"()=>{let h=rinvHtml(db.rcm[0]);return (h.match(/class=\x22?inv(?: |>|\x22)/g)||[]).length>=2 && h.includes('PAYMENT VOUCHER') && h.includes('347.22')}")
restore()
check('current export-import 3 cycles',True,"()=>{let start=JSON.stringify(db);for(let i=0;i<3;i++){const txt=JSON.stringify({...db,ver:VER,app:'InvoiceCraft'});fire('change',{id:'imp',dataset:{},files:[txt]})}return start===JSON.stringify(db)}")
check('bad JSON preserves current state',True,"()=>{let x=JSON.stringify(db);fire('change',{id:'imp',dataset:{},files:['bad JSON']});return x===JSON.stringify(db)}")
check('missing optional arrays accepted',True,"()=>{fire('change',{id:'imp',dataset:{},files:['{\"orders\":[]}']});return db.presets.length>0 && !db.rcm.length}")
check('legacy shipping difference migration',6,"()=>Number(mig({shipFee:5,shipDiff:1}).actShip)")
check('legacy payout auto links old month orders',2,"()=>{"+"""db.orders=[{id:1,date:'2026-01-01'},{id:2,date:'2026-01-04'}];return payouts({m:'2026-01',depositUsd:30})[0].orders.length}""")
restore()
check('malformed nested record rejected atomically',4,"()=>{fire('change',{id:'imp',dataset:{},files:[JSON.stringify({orders:[{}]})]});return JSON.parse(localStorage.getItem(K)).orders.length}")
restore()
check('duplicate ID rejected',4,"()=>{let d=structuredClone(db);d.orders.push(d.orders[0]);fire('change',{id:'imp',dataset:{},files:[JSON.stringify(d)]});return db.orders.length}")
restore()
check('malformed actual value explicitly reported on restore',True,"()=>{let d=structuredClone(db);d.orders[0].printifyInr='invalid';fire('change',{id:'imp',dataset:{},files:[JSON.stringify(d)]});return !('printifyInr' in db.orders[0])}")
restore()
check('order invoice rate stable with fallback change',actual[1]['rate'],"()=>{S().inr=130;return calc(db.orders[1]).rate}")
check('empty month profit',0,"()=>mcalc('2025-01').profitInr")
check('rounded per line GST equals rounded invoice GST',True,"()=>{let r={l:.03,r:.03};return Number((r.l*.18).toFixed(2))+Number((r.r*.18).toFixed(2))===Number(rc(r).gst.toFixed(2))}")
report()
restore()
check('offsite max 100 USD',100,"()=>calc({sale:1000,offsite:true}).off")
check('offsite max 100 USD automatic',100,"()=>calc({sale:1000,offsite:true,inrv:97500,taxi:0}).off")
check('no estimated GST on duplicate split-offsite entry',0,"()=>{dr={sp:true,fb:4.5,sale:30,offsite:true};return calc(oFromDr()).fees}")
check('customer USD and INR fee ledger reconciles exactly',0,"()=>{let c=calc(db.orders[1]);return (c.payout-(c.gross-c.exchangeCost-c.fees-c.off))*c.rate}")
check('reject nonfinite sale on backup',True,"()=>{let d=structuredClone(db);d.orders[0].sale='1e999';fire('change',{id:'imp',dataset:{},files:[JSON.stringify(d)]});return Number.isFinite(calc(db.orders[0]).net)}")
restore()
check('order dashboard changes when actual INR cost added',True,"()=>{ui.range=0;let a=V.dash();db.orders[0].printifyInr=0;return V.dash()!==a}")
check('mixed loss INR visible to loss filter',True,"()=>{ui.flt='loss';ui.q='';db.orders[0].printifyInr=10000;return V.list().includes(db.orders[0].no)}")
restore()
check('actual in CSV has explicit source column',True,"()=>csv().split('\u005cn')[0].includes('Actual Printify')")
check('partial estimated and actual bank row flags',True,"()=>{let r=db.rcm[0];r.payouts.push({balanceInr:1000,depositUsd:10,effectiveRate:90,orders:[]});let c=mcalc(r.m);return c.bank===4425&&!c.confirmed}")
restore()
check('negative loss after mark paid stays red monthly',True,"()=>{db.rcm[0].paid=true;return mledger(mcalc(db.rcm[0].m)).includes('net neg')}")
check('source claims only 80 of 96 without paging',96,"()=>{ui.pq='';return (V.plist().match(/data-a=puse/g)||[]).length}")
check('order view detail split fee USD each appears once',1,"()=>{let c=calc(db.orders[1]);return ledger(c,db.orders[1]).split('Transaction ')[1].split(' · Processing')[0].split(m(c.tx/c.rm)).length-1}")
restore()
# Generic settings handler tests for all rendered controls. Individual value persisted and loaded.
import re
settingshtml=ev('V.set()')
for k,tag,typ in [(re.search(r'data-s=([\w]+)',t)[1],t.split()[0],re.search(r'type=(\w+)',t)[1] if re.search(r'type=(\w+)',t) else 'text') for t in re.findall(r'<(?:input|select|textarea)\b[^>]*data-s=[^>]*>',settingshtml)]:
 val=(False if data['settings'].get(k) else True) if typ=='checkbox' else (7.25 if typ=='number' else ('a4' if k=='paper' else 'l' if k=='orient' else 'fixed' if k=='mrate' else 'QA'))
 ck('Settings persistence',k,val,ev("([k,v,t])=>{fire('change',{dataset:{s:k},type:t,value:String(v),checked:v});return load().settings[k]}",[k,val,typ]))
restore()
check('new preset from form',True,"()=>{for(let [i,v] of Object.entries({pn:'QA',pv:'XL',ps:'21',pp:'10',ph:'5',pa:'4'}))$('#'+i).value=v;A.padd();return db.presets[0].n==='QA' && db.presets[0].act===4}")
check('edit preset form',22,"()=>{A.pedit({i:0});$('#ps').value='22';A.padd();return db.presets[0].sale}")
check('use preset copies costs',True,"()=>{A.puse({i:0});return dr.sale==='22'&&dr.actShip==='4'}")
check('remove preset',96,"()=>{A.pdel({i:0});return db.presets.length}")
restore()
check('rgen creates missing number once',True,"()=>{let r=db.rcm.find(r=>!r.rno);A.ropen({id:r.id});A.rgen();let x=db.rcm.find(v=>v.id===r.id).rno;A.ropen({id:r.id});A.rgen();return x===db.rcm.find(v=>v.id===r.id).rno && !!x}")
check('rdel removes record',4,"()=>{A.rdel();return db.rcm.length}")
restore()
check('print page dimensions landscape A4',True,"()=>{Object.assign(S(),{paper:'a4',orient:'l',pmargin:10});let v=pageCss();return v[2]===297&&v[3]===210&&v[4]===10}")
check('missing commercial details use fallback',True,"()=>invHtml({sale:25,qty:0}).includes('Customer')")
check('storage write failure produces warning',True,"()=>{let fn=localStorage.setItem;try{localStorage.setItem=()=>{throw Error('quota')};save();return storageWarning && $('#toast').textContent.includes('storage failed')}finally{localStorage.setItem=fn}}")
check('storage warning clears on retry',False,"()=>{save();return storageWarning}")
check('reset in disposable database',True,"()=>{A.reset();return !db.orders.length&&!db.rcm.length&&db.presets.length===CATALOG.length}")
restore()
check('all time excludes future orders',4,"()=>{db.orders.push({...db.orders[0],date:'2050-01-01'});ui.range=7;return V.dash().includes('2050')?99:db.orders.filter(o=>o.date<=today()).length}") if False else None
check('save duplicate links rejected within imported month',False,"()=>{let r=db.rcm[0];r.payouts.push({...r.payouts[0]});A.ropen({id:r.id});return !!commitR()}")
restore()
check('actual override on real backup export with revised field',1700.55,"()=>{db.orders[0].printifyInr='1700.55';let snap=JSON.stringify(db);fire('change',{id:'imp',dataset:{},files:[snap]});return calc(load().orders[0]).printifyCostInr}")
check('manual expense classification leaves full RCM unchanged',347.22,"()=>{for(let [k] of RF)S()['ov_'+k]=false;return rc(db.rcm[0]).gst}")
restore()
check('duplicate order numbers refused',4,"()=>{A.dup({id:db.orders[0].id});dr.no=db.orders[0].no;A.save();return db.orders.length}")
report()
# Statement-backed vs allocated new-style payouts under every fee classification; 256 masks each.
bankm=ev("""()=>{let old=db;let out=[];try{for(let mask=0;mask<256;mask++)for(let fixed of [true,false]){let r={m:'2026-01',id:3,payouts:[{fromOrders:true,orders:['1'],effectiveRate:100,...(fixed?{balanceInr:2800,depositUsd:28,bankCredit:2800}:{})}]};db={settings:{...DS,conv:0,inr:100,pay:0},rcm:[r],orders:[{date:'2026-01-01',id:1,sale:30,prod:10,fx:100}],presets:[]};RF.forEach(([k],i)=>{r[k]=2**i;S()['ov_'+k]=!!(mask&(1<<i))});let c=mcalc(r.m);out.push([c.profitInr,c.bank,c.gstInr])}}finally{db=old}return out}""")
for i,(pf,bank,g) in enumerate(bankm):
 mask=i//2; receipt=2800 if i%2==0 else 3000-mask
 ck('Settlement fee masks',str(i),True,abs(pf-(receipt-1000-45.9))<1e-8 and abs(bank-receipt)<1e-8 and abs(g-45.9)<1e-8)
restore()
check('zero expense month no orders full GST when excluded fees exist',-18,"()=>{db.orders=[];db.rcm=[{m:'2026-02',t:100}];return mcalc('2026-02').profitInr}")
check('zero bank entry is a final actual receipt',True,"()=>{let p={fromOrders:true,balanceInr:100,depositUsd:1,bankCredit:'0',orders:[]};return payoutReady(p)}")
restore()
check('cross-month linked order excluded exactly once',True,"()=>{let r=db.rcm[0],o=db.orders[2];r.payouts[0].orders.push(String(o.id));return mcalc('2026-07').n===0 && mcalc('2026-10').n===3}")
check('two independent payouts share monthly fee once',2900,"()=>{db.orders=[{id:1,date:'2026-01-01',sale:10,fx:100},{id:2,date:'2026-01-02',sale:20,fx:100}];let r={m:'2026-01',l:100,payouts:[{fromOrders:true,orders:['1'],effectiveRate:100},{fromOrders:true,orders:['2'],effectiveRate:100}]};return payouts(r).reduce((a,p)=>a+p.balanceInr,0)}")
restore()
check('PDF filename sanitised',True,"()=>!safeName('A/B').includes('/')")
check('customer quantity and discount total',True,"()=>{let h=invHtml({sale:18,shipFee:4,disc:2,qty:2,hsn:'QA'});return ['$10.00','$20.00','$22.00','$24.00','QA'].every(v=>h.includes(v))}")
check('zero extra fee month without invoice negative profit red',True,"()=>{db.orders=[{sale:10,prod:100,date:'2026-01-01'}];return mledger(mcalc('2026-01')).includes('net neg')}")
restore()
# Additional component and data-flow evidence for standalone report.
(root/'meta.json').write_text(json.dumps(ev("""()=>({actions:Object.keys(A),settings:Object.keys(S()),rates:db.orders.map(o=>calc(o).rate),dashboard:V.dash(),sum:sum(db.orders),doc:db.rcm.map(r=>[r.m,r.rno||'',r.idate,r.rdate,r.pdate,r.paid]),sacs:RF.map(([k])=>[k,S()['rcm_sac_'+k]||S().rcm_sac||'blank'])})""")))
report()
restore()
# Test the literal bytes passed by application export actions, with download boundary captured.
ev("()=>{globalThis.downloads=[];globalThis.Blob=class{constructor(parts,opts){this.text=parts.join('');this.type=opts.type}};globalThis.URL={createObjectURL:b=>(downloads.push(b),'audit'),revokeObjectURL(){}};document.createElement=()=>({click(){},remove(){}})}")
check('JSON download action preserves every record',True,"()=>{A.xjson();let x=JSON.parse(downloads.at(-1).text);return x.ver===VER && ['settings','presets','orders','rcm'].every(k=>JSON.stringify(x[k])===JSON.stringify(db[k]))}")
check('order CSV lines',5,"()=>{A.xcsv();return downloads.at(-1).text.split('\u005cn').length}")
check('RCM CSV lines and October full GST',True,"()=>{A.xrcm();let s=downloads.at(-1).text;return s.split('\u005cn').length===6 && s.includes('2026-10') && Math.abs(Number(s.split('2026-10')[1].split(',').at(-3).replaceAll('\u0022',''))-347.22)<1e-7}")
check('malformed JSON arrays rejected',4,"()=>{fire('change',{id:'imp',dataset:{},files:['{\"orders\":{},\"rcm\":{}}']});return db.orders.length}")
check('old minimal schema restores and freezes default',True,"()=>{fire('change',{id:'imp',dataset:{},files:[JSON.stringify({orders:[{id:1,date:'2025-01-01',sale:5,shipFee:2,shipDiff:1}]})]});return db.orders[0].fx===95 && calc(db.orders[0]).ship===3}")
restore()
check('reopen from saved JSON retains payout links',True,"()=>{save();db=load();return db.rcm[0].payouts[0].orders.length===2 && mcalc('2026-10').n===2}")
check('corrupt stored JSON reports recovery required',True,"()=>{localStorage.setItem(K,'bad');mem=null;let d=load();return !!d.recoveryWarning}")
restore()
check('unpaid voucher flag separate from supplier payment date',True,"()=>{let r=db.rcm[0];return !r.paid && rinvHtml(r).includes(fd(r.pdate))}")
check('legacy mixed USD and INR excludes extra tax from revenue when totals consistent',True,"()=>{let o={sale:30,inrv:3120,tot:32,taxi:200},c=calc(o);return Math.abs(c.payout-(30-c.exchangeCost-c.fees-c.off))<1e-10}")
check('legacy payouts without settlement date appear confirmed',True,"()=>mcalc('2026-10').confirmed")
check('explicit total below merchandise without tax warns on saved order',True,"()=>{A.new();Object.assign(dr,{sale:30,actShip:0,shipFee:0,inrv:3000,tot:10});A.save();return !!ui.sheet}")
check('new-style estimated settlement with actual bank is explicitly marked settlement estimate',True,"()=>{let r=db.rcm[0];r.payouts=[{fromOrders:true,orders:r.payouts[0].orders,bankCredit:3525}];let c=mcalc(r.m);return !!c.estimatedSettlement}")
restore()
check('change date moves order while linked prevented',True,"()=>{let o=db.orders[0];A.edit({id:o.id});dr.date='2026-12-25';A.save();return db.orders[0].date===o.date}")
check('drawer order link commit uniqueness',True,"()=>{let r=db.rcm[0];return r.payouts[0].orders.length===new Set(r.payouts[0].orders).size}")
restore()
check('RCM generated rates show full taxable base',True,"()=>{let h=rinvHtml(db.rcm[0]);return ['1,929.00','347.22','2,276.22'].every(k=>h.includes(k))}")
check('INR-only monthly KPI uses whole rupees',True,"()=>V.rcm().includes(inrf(-5409.419902879236))")
check('estimated bank displays 92.99 when actual removed',3525.2509,"()=>{delete db.rcm[0].payouts[0].bankCredit;return mcalc('2026-10').bank}")
restore()
check('legacy market percentage fallback',3524.398,"()=>{let p=db.rcm[0].payouts[0];delete p.bankCredit;delete p.effectiveRate;return mcalc('2026-10').bank}")
restore()
check('correct fallback after deleting link and reassigning',True,"()=>{A.ropen({id:db.rcm[0].id});let p=rd.payouts[0];let id=p.orders.pop();commitR();let h=payoutEditor({payouts:[{orders:[]}]});return h.includes('display:block\u0022><input type=checkbox data-pi=\u00220\u0022 data-order=\u0022'+id)}")
report()
sw=json.loads(subprocess.check_output(['node',str(root/'swtest.cjs')]))
ck('Service worker','all precache entries present',True,all((src/p).exists() for p in sw['assets']))
ck('Service worker','unrelated same-origin cache survives activation',True,'unrelated-cache' not in sw['del'])
# Date range, currency and integrity checks with safe, non-executable fixtures.
restore()
check('7 days means seven calendar days, future excluded',1,"()=>{let t=today();db.orders=[0,7,-1].map((d,i)=>({id:i+1,date:iso(Date.parse(t)-d*864e5),sale:10}));ui.range=7;return +V.dash().match(/Invoices<\/small><b>(\d+)/)[1]}")
restore()
check('correct empty filter output',True,"()=>{ui.flt='all';ui.q='unknown-123';return V.list().includes('No matching invoices')}")
check('multi-tab stale snapshot preserves new order',5,"()=>{let a=JSON.parse(JSON.stringify(db)),b=JSON.parse(JSON.stringify(db));db=a;db.orders.push({...db.orders[0],id:123});save();db=b;S().shop='QA';save();return load().orders.length}")
report()
