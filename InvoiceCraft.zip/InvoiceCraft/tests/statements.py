"""Verify the audited statement sequence using original CSV rows in running order."""
import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

directory = Path(sys.argv[1])
results = []
def check(label, expected, actual):
    results.append([label, expected, actual])
    assert expected == actual, (label, expected, actual)

def transactions(month):
    source, = directory.glob(f'etsy_statement_2026_{month}*.csv')
    with source.open(encoding='utf-8-sig') as file:
        return list(reversed(list(csv.DictReader(file))))

def net(row):
    return int(row['Net'].replace('₹','').replace(',',''))

june, july, august = (transactions(i) for i in (6,7,8))
check('June net movement', -475, sum(map(net,june)))
check('July card settlement', [475], [net(r) for r in july if r['Type']=='Payment'])
check('July listing-type rows', 36, sum(r['Title'].startswith('Listing fee') for r in july))
check('July eligible fees', 684, -sum(net(r) for r in july if r['Title'].startswith('Listing fee')))
order_rows=[r for r in july if '4131798397' in (r['Title']+r['Info']) and r['Type']!='Sale']
check('July order deductions', 570, -sum(map(net,order_rows)))
check('July closing reconstructed from June activity',1714,sum(map(net,june+july)))
balance=1714
categories=Counter()
for r in august:
    if r['Type']=='Deposit':
        check('First August payout date','August 17, 2026',r['Date'])
        check('Balance at payout',1322,balance)
        check('Transfer on statement',1322,int(re.search(r'₹([\d,]+)',r['Title'])[1].replace(',','')))
        break
    balance+=net(r)
    categories[r['Title']]-=net(r)
else:
    raise ValueError('Deposit missing')
check('August listings before deposit',380,categories['Listing fee ($0.20 USD)'])
check('August ads before deposit',12,categories['Etsy Ads'])
october=[r for r in transactions(10) if '4212387304' in (r['Title']+r['Info'])]
check('October sale payment',3020,next(net(r) for r in october if r['Type']=='Sale'))
check('October buyer tax',244,-next(net(r) for r in october if r['Title']=='Sales tax paid by buyer'))
oct_rows = transactions(10)
def total_where(predicate):
    return sum(net(row) for row in oct_rows if predicate(row))
check('October gross sale postings', 6066, total_where(lambda r:r['Type']=='Sale'))
check('October fee and marketing entries', -1929, total_where(lambda r:r['Type'] in ('Fee','Marketing')))
check('October tax including buyer tax, TCS and TDS', -548, total_where(lambda r:r['Type']=='Tax'))
check('October eligible listings and ads', -350, total_where(lambda r:r['Title'].startswith('Listing fee') or r['Title']=='Etsy Ads'))
check('October balance from sale activity', 3589, total_where(lambda r:r['Type'] in ('Sale','Fee','Marketing','Tax')))
check('October 2 card credit', [('October 2, 2026',2317)], [(r['Date'],net(r)) for r in oct_rows if r['Type']=='Payment'])
check('October Offsite Ads charged per sale', [-427,-427], sorted(net(r) for r in oct_rows if r['Title']=='Offsite Ads fee'))
check('November 2 Etsy transfer', True, any(r['Type']=='Deposit' and r['Date']=='November 2, 2026' and '₹3,589' in r['Title'] for r in transactions(11)))
Path(__file__).with_name('statement-results.json').write_text(json.dumps(results))
print(f'{len(results)} statement checks passed')
