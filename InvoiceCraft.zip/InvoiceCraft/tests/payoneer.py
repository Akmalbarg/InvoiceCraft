"""Verify the withdrawal model, editor, and October fixture using a decimal oracle."""
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
app = subprocess.Popen(['node', str(root/'vm.cjs')], text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
def run(code, *arg):
    app.stdin.write(json.dumps([code, *arg])+'\n')
    app.stdin.flush()
    answer = json.loads(app.stdout.readline())
    if 'error' in answer:
        raise RuntimeError(answer['error'])
    return answer.get('v')

def check(label, actual, expected):
    if actual != expected:
        raise AssertionError(f'{label}: {actual!r} != {expected!r}')
    print('PASS', label)

def rounded(x, precision='0.01'):
    return x.quantize(D(precision), rounding=ROUND_HALF_UP)

base = dict(depositUsd='37.91', feeUsd='0.76', preFeeRate='94.90', confirmedInr='3525.54', bankCredit='3525', sentDate='2026-11-02', withdrawalDate='2026-11-03', bankDate='2026-11-03')
def withdrawal(**changes):
    return run('withdrawal', {**base, **changes})

g, f, rate = map(D, ['37.91','0.76','94.90'])
net = g-f
expected = rounded(net*rate)
for key, value in dict(net=net, expected=expected, pct=rounded(100*f/g), effective=rounded(expected/g,'0.0001'), transferDiff=0, bankDiff=D('3525')-expected).items():
    check('Confirmation '+key, D(str(withdrawal()[key])), value)
for label, changes, status in [
    ('Recorded bank', {}, 'Difference Needs Review'),
    ('Bank agrees', {'bankCredit':'3525.54'}, 'Reconciled'),
    ('One paise tolerance', {'bankCredit':'3525.53'}, 'Reconciled'),
    ('Two paise short', {'bankCredit':'3525.52'}, 'Difference Needs Review'),
    ('No bank evidence', {'bankCredit':''}, 'Incomplete'),
    ('No confirmed amount, independent bank', {'confirmedInr':'','bankCredit':'3525.54'}, 'Reconciled'),
    ('Transfer discrepancy survives matching bank', {'confirmedInr':'3526','bankCredit':'3526'}, 'Difference Needs Review'),
    ('Missing fee', {'feeUsd':'','bankCredit':'3525.54'}, 'Estimated'),
    ('Missing rate', {'preFeeRate':'','bankCredit':'3525.54'}, 'Incomplete'),
    ('Missing gross', {'depositUsd':'','bankCredit':'3525.54'}, 'Incomplete'),
    ('Zero fee', {'feeUsd':'0','confirmedInr':'','bankCredit':'3597.66'}, 'Reconciled'),
    ('Cross year', {'sentDate':'2026-12-31','withdrawalDate':'2027-01-01','bankDate':'2027-01-02','bankCredit':'3525.54'}, 'Reconciled'),
]:
    check(label, withdrawal(**changes)['status'], status)
check('One paise difference remains visible',withdrawal(bankCredit='3525.53')['bankDiff'],-0.01)
check('Blank fee cannot produce net USD',withdrawal(feeUsd='')['net'],None)
check('Derived gross is never verified',withdrawal(inferredGross=True)['expected'],None)
for key,value in [('depositUsd','0'),('feeUsd','-1'),('feeUsd','37.92'),('feeUsd','0.001'),('preFeeRate','0'),('preFeeRate','-1'),('preFeeRate','abc'),('confirmedInr','-1'),('bankCredit','-1'),('withdrawalDate','2026-02-30'),('withdrawalDate','2026-10-01'),('bankDate','2026-11-01')]:
    check('Reject '+key+' '+value,bool(withdrawal(**{key:value})['error']),True)
for gross,fee,quote in [('0.01','0','0.5'),('1.01','1','1.5'),('9876543.21','1234.56','91.87654321'),('17.99','17.99','100')]:
    v=rounded((D(gross)-D(fee))*D(quote))
    check('Decimal oracle '+gross,withdrawal(depositUsd=gross,feeUsd=fee,preFeeRate=quote,confirmedInr='',bankCredit=str(v))['expected'],float(v))
check('Older manual effective rate retained',run("p=>payoutBank(p,{pay:2})",{'depositUsd':'10','effectiveRate':'92.99'}),929.9)
check('Confirmed transfer alone leaves independent bank blank',withdrawal(bankCredit='')['bankDiff'],None)
check('No estimated fee stacked on actual fee',run("p=>payoutBank(p,{pay:25})",{**base,'confirmedInr':'','bankCredit':'','effectiveRate':'75'}),3525.54)
check('Unknown quote cannot use old effective as pre-fee',withdrawal(preFeeRate='',effectiveRate='92.99')['expected'],None)
fixture = Path(sys.argv[1]).read_text()
run("s=>{db=parseBackup(JSON.parse(s));}",fixture)
run("""var oct=()=>db.rcm.find(r=>r.m==='2026-10'), totals=()=>{let c=mcalc('2026-10');return [c.bank,c.external,c.cashBeforeGst,c.gstOutstanding,c.profitInr,c.gstPaid].map(v=>Math.round(v*100))};
var original=JSON.stringify(db), orderResults=JSON.stringify(db.orders.map(o=>calc(o).net)), others=JSON.stringify(db.rcm.filter(r=>r!==oct()));
var edit=()=>A.ropen({id:oct().id}), input=(k,v)=>fire('input',{dataset:{pi:'0',pkey:k},value:v});""")
check('Original historical cash and profit',run('totals()'),[352500,332428,20072,34722,-14650,0])
run('edit();rd.payouts[0].compatibleMetadata="keep";')
for key in ('feeUsd','preFeeRate','confirmedInr','withdrawalDate'):
    run('pair=>input(...pair)',[key,base[key]])
check('Unsaved edits preserve stored record',run('JSON.stringify(db)===original'),True)
check('Summary updates during typing',run("""document.querySelector('[data-withdrawal="0"]').innerHTML.includes('Difference Needs Review')"""),True)
run('A.rsave();db=load()')
check('New details survive save and refresh',run("oct().payouts.map(p=>[p.feeUsd,p.preFeeRate,p.confirmedInr,p.withdrawalDate,p.bankCredit,p.compatibleMetadata])"),[['0.76','94.90','3525.54','2026-11-03','3525','keep']])
check('Payout links and prior metadata unchanged',run("Object.entries(JSON.parse(original).rcm.find(r=>r.m==='2026-10').payouts[0]).every(([k,v])=>JSON.stringify(oct().payouts[0][k])===JSON.stringify(v))"),True)
check('Fee and quote alone preserve profit',run('totals()'),[352500,332428,20072,34722,-14650,0])
run('edit();input("feeUsd","100");A.rsave()')
check('Invalid save retains draft, database untouched',run("rd.payouts[0].feeUsd==='100' && oct().payouts[0].feeUsd==='0.76' && !!ui.sheet"),True)
run('input("feeUsd","0.76");input("bankCredit","3525.54");A.rsave()')
check('Manually confirmed higher bank credit',run('totals()'),[352554,332428,20126,34722,-14596,0])
check('All other months unchanged',run('JSON.stringify(db.rcm.filter(r=>r!==oct()))===others'),True)
check('Order USD profit unchanged',run('JSON.stringify(db.orders.map(o=>calc(o).net))===orderResults'),True)
run('var exported;dl=(name,bytes)=>{exported=bytes};A.xjson();db=parseBackup(JSON.parse(exported));')
check('Real export preserves all new and legacy keys on restore',run("JSON.stringify(db.rcm)===JSON.stringify(JSON.parse(exported).rcm)&&oct().payouts[0].compatibleMetadata==='keep'"),True)
run('edit();A.pplus();var p2=rd.payouts[1];Object.assign(p2,{orders:[],depositUsd:"5",feeUsd:"0",preFeeRate:"90",confirmedInr:"450",bankCredit:"450"});A.rsave();')
check('Two distinct withdrawals retain rates and fee provenance',run("oct().payouts.map(p=>withdrawal(p).expected)"),[3525.54,450])
run('edit();A.pminus();A.rsave()')
check('Removing the last withdrawal preserves the first',run('oct().payouts.length===1&&oct().payouts[0].confirmedInr==="3525.54"'),True)
check('Four payout groups and unique amount/date fields',run("""()=>{let h=payoutEditor(oct());return ['Etsy transfer','Payoneer withdrawal','Bank receipt','Reconciliation summary'].every(k=>h.includes('<h3>'+k+'</h3>'))&&['depositUsd','bankCredit','feeUsd','sentDate','bankDate','withdrawalDate','preFeeRate'].every(k=>h.split('data-pkey="'+k+'"').length===2)}"""),True)
run("""edit();var first=rd.payouts[0], ids=first.orders.slice();first.orders=[ids[0]];Object.assign(first,{depositUsd:'20',feeUsd:'.40',preFeeRate:'95',confirmedInr:'1862',bankCredit:'1862'});A.pplus();Object.assign(rd.payouts[1],{orders:[ids[1]],balanceInr:'1600',depositUsd:'17.91',feeUsd:'.36',preFeeRate:'94.78',confirmedInr:'1663.39',bankCredit:'1663.54',sentDate:'2026-11-09',withdrawalDate:'2026-11-10',bankDate:'2026-11-11',feesWithheld:'0'});A.rsave()""")
check('Distinct orders, fee rates, calendar dates and bank differences',run("oct().payouts.map(p=>[p.orders.length,p.bankDate,withdrawal(p).expected,withdrawal(p).status])"),[[1,'2026-11-03',1862,'Reconciled'],[1,'2026-11-11',float(rounded(D('17.55')*D('94.78'))),'Difference Needs Review']])
check('Two actual bank credits and costs counted once',run('totals()'),[352554,332428,20126,34722,-14596,0])
check('Zero bank credit overrides positive confirmed transfer',run("p=>payoutBank(p,{pay:2})",{**base,'bankCredit':'0'}),0)
layout=(root.parent/'index.html').read_text()
check('Desktop two-column field grid', '.rcm-form .g2{grid-template-columns:repeat(2,minmax(0,1fr))' in layout,True)
check('Narrow viewport one-column rule', '@media(max-width:420px){.rcm-form .payout-card .g2{grid-template-columns:minmax(0,1fr)}' in layout,True)
check('Narrow card one-column rule', '@container(max-width:360px){.rcm-form .payout-card .g2{grid-template-columns:minmax(0,1fr)}' in layout,True)
check('Legacy single-payout transfer and bank dates retain actual calendar values',run("()=>{let p=payouts({m:'2026-10',balanceInr:'3589',depositUsd:'37.91',sentDate:'2026-11-02',bankDate:'2026-11-03'})[0];return [p.sentDate,p.bankDate]}"),['2026-11-02','2026-11-03'])
run('edit();delete rd.payouts[0].withdrawPct;A.rsave()')
check('Saving leaves absent historical withdrawal percentage absent',run("!Object.hasOwn(oct().payouts[0],'withdrawPct')"),True)
app.stdin.close()
app.wait()
