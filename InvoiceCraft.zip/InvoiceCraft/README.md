# InvoiceCraft 3.0.0

Open index.html to use the offline application. The FBIL setup instructions are in guide.html. Open Audit-3.0.0.html for release checks and limitations.

# InvoiceCraft user guide
Version 2.2.2 · Etsy orders, Payoneer payouts and monthly RCM

## Product profit simulator

Use Simulator to model a product, compare saved scenarios and solve for a target unit price. See guide.html for examples and the full assumptions. The Monthly screen and Etsy invoice editor include Copy CSV Analysis Prompt.

## Payoneer withdrawals

Open the existing payout and copy the fee, pre-fee rate, confirmed INR and withdrawal date from the transfer confirmation. Enter the bank credit separately. The summary shows the signed differences. See guide.html and Audit-2.2.2.html for the calculations and tests.

## Reconciling payouts and card payments

Open the month containing the existing payout. For a single billing month you can still enter one withheld amount. For several months, click **Add billing month** on the existing payout. Enter the month, amount and whether the allocation is confirmed or estimated. A blank single amount leaves coverage unknown. An explicit zero records zero coverage. Removing an allocation keeps the payout and its order links.

For the August 17 example, open the July record containing the existing payout, add **July 2026 · ₹684** and **August 2026 · ₹392**, then save. The August invoice must already exist. Use the Monthly tab’s **Copy CSV Analysis Prompt** to copy the offline statement-analysis instructions.

Under **Etsy card payments**, enter the date the bank posted the payment, even when paying a previous month’s invoice. Enter the Etsy principal and the full extra charge separately. Allocate the principal to its original fee months. If your statement gives one combined debit, subtract the Etsy principal to find the extra charge. For a refund, select the original payment and enter only the principal and bank charges actually returned, both as positive amounts. A fee-only refund can use zero principal and no billing allocations. Net invoice lines should reflect documented supplier credits. A bank reversal reopens the principal balance; it does not cancel the supplier expense.

Use **Payments only** when a month has settlements but the monthly fee invoice has not arrived. Clear it when you enter the fee invoice. Profit recognizes selected Etsy expenses in their billing month and extra card charges in the allocated billing months, in proportion to the principal. Refunds reduce the original charge in those months. A standalone charge without principal belongs to the month of the record. The card principal settles existing fees. Cash already reduced by a different month’s fees gets a matching add-back in the payout record’s month. The expense remains in the billing month. The balance without confirmed settlement can include unidentified withholdings; check statements before treating it as payable.

## Buyer sales tax
When the INR tax field is blank, InvoiceCraft converts the buyer’s USD sales tax at the Etsy payment rate and rounds it to the nearest whole rupee before calculating fees and payout. An explicit statement amount, including zero, takes priority. Previously saved orders with blank tax may show revised estimates.

Sales tax is checked at the Etsy payment rate implied by the tax-inclusive INR and USD totals. For whole-rupee statement amounts the check rounds to rupees. For amounts with a fractional rupee it compares paise. The payout uses the entered statement tax.

## Etsy fee rounding
Each USD Etsy fee is rounded to the nearest cent before profit is calculated. A $1.914 fee deducts $1.91. Two separate $1.914 fees deduct $3.82. Existing orders with fractional-cent fees may show a slightly different estimate when reopened.

## Start here
1. Before updating, open your existing app and choose **Settings → Export backup (JSON)**. Keep the downloaded file. Extract the entire new ZIP. For an installed app, update the files at the same website address, then close and reopen the app. Check the version under Settings → About.
2. Open **index.html** to run locally. To install on a phone with offline support, serve the entire folder from an HTTPS website, open it once online, then use the browser’s install or Add to Home Screen option. Keep the icons and lib folders alongside index.html. The guide is also available under Settings → Help.
3. Open Settings and enter your shop, invoice details, currency and fee rates. Add one order, check its fee breakdown against Etsy, then record the corresponding payout in Monthly fees & RCM GST.
4. Data belongs to the browser and website address you used. A different browser, a new address or opening a downloaded copy can show an empty app. Import your JSON backup there if needed.

## Record an order
Tap **+**, enter the order date and Etsy order number, then type the item or choose a preset. Enter the total discounted merchandise price for this order, the production cost, the shipping paid by the buyer and the shipping you actually paid. Order money fields use your shop currency unless marked ₹. The invoice quantity divides the merchandise amount into units. Enter the full line amount even when the buyer bought several units.

Actual Printify Cost (INR) is optional. Enter the full rupee charge for this order, including production, shipping and conversion. Zero records a free order. Clear the field to restore the estimate. The order and monthly INR profit use the charge once. USD profit continues to use the estimated costs. Monthly shows Actual, Estimated, or counts for both.

Shipping difference equals buyer shipping minus actual shipping. For example, collecting $4.99 and paying $6.49 shows a $1.50 shortfall. The app already includes both amounts in profit. Use Notes for details you want to search later.

### Automatic Etsy fees
Enter **₹ Etsy paid for this sale (tax included)** from the sale record, plus either **sales tax in ₹** (enter 0 for a tax-free sale) or the **buyer total including sales tax in USD**. The buyer total must cover merchandise plus shipping. With a valid buyer total, the app uses it to derive the market rate. If you also type tax, it uses that tax amount for the fee base. Check that both entries describe the same order.

With the default 2.5% conversion cut, ₹3,046 from Etsy represents ₹3,124.10 before conversion. Subtract ₹270 sales tax to get a ₹2,854.10 fee base. At the app defaults, transaction is ₹185 (rounded down), regulatory is ₹1 (nearest rupee), and offsite is ₹428 if enabled on item plus shipping. Processing uses ₹3,046 × 5% + ₹25, rounded to ₹177. The app converts each rupee fee back to USD at the derived market rate. These are configurable calculations to reconcile with your statements.

For the market rate, divide the before-conversion total by the tax-inclusive buyer total in USD. With only a rupee tax amount, divide the tax-exclusive market value by item plus shipping in USD. The lower **Etsy pays** rate includes the conversion cut. The app has already accounted for this cut in the order payout.

### Manual fees and order profit
Leave the automatic inputs empty to type the Etsy fees from your statement. Use **Split Etsy fees** for individual lines or use a single total. When automatic calculation is active, enter only additional fees. Turn **Auto-add offsite fee** on for an eligible sale when the offsite amount has been excluded from your typed fees. Including it in both places deducts it twice.

Read **Amount breakup** before saving. Order profit starts with the Etsy payout and subtracts production, actual shipping, estimated Payoneer charges, Printify conversion and any enabled TDS, TCS and RCM. The estimated Payoneer charge uses the configured percentage of payout. Printify conversion uses production plus actual shipping. Margin divides profit by item plus buyer shipping. The INR order result uses the derived order rate when automatic fees apply. With only an Etsy INR amount it uses that amount divided by gross sales. Otherwise it uses the entered or saved fallback rate.

## Find orders and issue customer invoices
**Orders** searches number, item and notes. Filter by Offsite, Not offsite, Loss (INR) or Loss (USD). Tap a row to edit, duplicate, delete, open the customer Invoice or print your internal Profit sheet. Duplicating carries over product and cost information. Review dates, customer, amounts, taxes, fees and references for the new sale.

Expand **Customer invoice details** in the order editor. Fill in bill-to and ship-to details, item description, quantity, HSN, origin, payment reference and invoice/payment dates. A blank ship-to uses bill-to. A blank invoice date uses the order date. Enter the item price after discounts and optionally record the discount and promo code for display. Save, open the order and tap **Invoice**. A blank invoice number gets the next available prefixed number. Commercial invoices with automatic Etsy fee calculations show the pre-conversion INR total less the recorded or calculated INR sales tax, rounded to the nearest rupee. Previously saved orders use this corrected value when their invoices are reopened or reprinted. It excludes your production costs and profit.

Use **Download PDF** for a file or **Print** for the browser print dialog. Settings controls paper, orientation, margin, logo, signature, declaration and footer. Filename placeholders include {inv}, {order}, {buyer}, {date} and {shop}. Check the preview and confirm paper size in the print dialog.

## Record monthly fees and payouts
Open **Monthly fees & RCM GST** and tap a month or **Add monthly invoice**. There is one record per invoice month. Reopen the existing month to add a second or third payout. Enter the Etsy invoice number and copy the statement’s INR lines into listing, transaction, renew sold, Etsy Ads, processing, offsite ads, regulatory and other fees. Include each applicable line when recording the fee invoice. Settings controls which of these count as extra costs in estimated monthly profit.

Under **Payments received**, use **Add payout +** once per bank deposit. The minus button removes the last payout from the open form. Tap Save to commit edits. Use one payout when Etsy combines several orders, even if their order exchange rates differ.

| Field | What to enter |
|---|---|
| Etsy sent on | Etsy’s dispatch date. A Monday transfer can have a Tuesday bank date. |
| Bank received on | Date credited to your bank. Use the actual date, even if Etsy sends the payout and your bank credits it the following month. |
| Orders covered | Tick every order in the transfer. Earlier orders are available. Orders assigned elsewhere are hidden. |
| Etsy sent (₹) | Net settlement amount from Etsy after deductions. A blank field can be estimated from linked orders. |
| Payoneer received (USD) | Dollar deposit on the Payoneer statement. The app can estimate it when orders are linked. |
| Payoneer rate after fees | INR per USD actually offered after Payoneer fees. This estimates bank credit while the bank amount is blank. |
| Actual bank credit (₹) | Exact amount that reached the bank. It takes precedence over the estimated credit. |

**Saving a date first.** Choose the invoice month, add a payout, enter the available date and tap **Save**. Reopen the same month to finish it. A pending payout contributes no bank proceeds until both settlement amounts are positive (entered or estimated) and a new-style payout has a rate or actual credit. Its orders remain eligible for order-based estimates. The bank date can fall outside the invoice month. It must be on or after the Etsy sent date. For October sales sent Monday 2 November 2026 and credited Tuesday 3 November, select October and enter both November dates. The payout counts toward October profit.

**November statement example.** The November 3 confirmation records $37.91 gross, $0.76 fee, ₹94.90 per net USD and ₹3,525.54 sent. The backup records ₹3,525.00 credited. See guide.html for the separate transfer and bank calculations.

Older payouts may also show **Withdrawal market rate** and **Withdrawal fee (%)**. This legacy estimate is separate from the verified Payoneer quote. With no actual credit or after-fee rate, these older rows estimate bank credit using the market rate less the withdrawal percentage. When the market rate is blank the app uses Etsy INR divided by received USD.

## Version 2.0.1

**IC-05 — Per-payout fee coverage.** Enter the amount of the selected monthly Etsy expenses already withheld from each payout. Enter 0 when none were withheld. Only linked, usable payouts offset the month's expenses. Explicit amounts may not exceed the month's selected fees in total. An amount incorporated in a computed bank estimate is accounted for once. Blank coverage on a statement-backed payout preserves an upper estimate and displays the possible range until confirmed.

**IC-11 — Invoice GST.** A saved monthly fee invoice replaces the order GST estimates in that month's profit. Estimated order GST is added back at each order's own exchange rate before the full invoice GST is charged. Without a monthly invoice the order estimates continue. Marking GST paid changes the outstanding balance only. USD order profit is unchanged.

## Read monthly profit

Open a month to see the actual and estimated Printify subtotals, amounts and counts. A payout with two actual charges of ₹1,700 and ₹1,600 and estimates of ₹1,450 and ₹1,500 costs ₹6,250. The linked expenses have already been deducted in profit. Under each payout you can also see its own breakdown. An unallocated receipt is held outside profit until linked. In a partially settled month, review the displayed range for monthly fees whose coverage is unknown.


**Before a usable payout**, the month starts with estimated order net profit and deducts extra monthly fee lines selected in Settings. A saved invoice replaces estimated order GST with the full invoice GST once. Without an invoice the order estimates continue. Automatic monthly conversion uses a gross-sales-weighted average of that month’s order rates. Settings also offers a fixed rate and rupee display.

**Once a usable payout exists**, the calculation starts with actual or estimated bank credit. It subtracts linked orders’ production, actual shipping and Printify conversion at their order rates, plus RCM on the full monthly invoice. It adds estimated profit before invoice GST for remaining unlinked orders in the month. Etsy fees already withheld from the settlement and Payoneer charges reflected in the bank credit are already accounted for. An earlier month’s order moves into the selected invoice month’s payout calculation once linked to a usable payout.

For example, if all orders in the ₹3,525 deposit are linked, linked fulfillment and conversion cost ₹2,000, and the invoice GST is ₹180, monthly profit is ₹1,345. If an order is missing, its costs may be missing too. Link every covered order and enter all bank credits and monthly fee lines before treating the result as reconciled. A negative monthly result is shown in red.

## RCM documents and payment status
Enter Etsy’s invoice date, your self-invoice date, payment date and payment reference from your records. Leave the self-invoice number blank to use Settings’ prefix and next number. **Save** stores the month. **Self-invoice** saves it and opens the self-invoice and payment voucher for print or PDF. Review supplier, recipient, place of supply, SAC codes, fee subtotal and GST. Each fee line uses its configured SAC or the fallback code. The configured GST percentage applies to the fee subtotal. **Pending / Paid** tracks your recorded status. Marking it paid updates the pending balance and does not send money or file a return.

## Dashboard, presets and settings
The dashboard summarizes order estimates. Choose 7, 30, 90 days or all time for net profit, gross sales, order count, margin and top items. The daily chart always covers 30 days. Use the monthly screen when comparing bank credits.

In **Presets**, search by product or variant. Tap a preset to start an order. Use Edit to update a reusable sale price, production cost and both shipping values. Blank actual shipping defaults to buyer shipping when saving a preset. Changes apply when you next use it. Keep separate presets for sizes with different costs.

**Settings** saves changes as you leave a field or change a switch. Set your shop name, currency symbol and default INR rate, review fee percentages and switch optional order deductions on or off. Financial and document settings are captured for saved records. Legacy records keep their imported settings before the first settings edit. Set the business identity, invoice numbering, currency code, HSN, dispatch origin, payment text, declaration and signature. For RCM documents, configure supplier, state, SAC codes and number sequence. For monthly profit, tick expenses that your per-order entries exclude. The phone menu position and bottom-button offset can be adjusted if your phone covers the Save button.

## Backup and recovery
Choose **Settings → Export backup (JSON)** for orders, monthly records, presets and settings. To restore, choose **Import backup**, select the JSON and review the count before confirming. Import replaces the current dataset. Export it first if you need both copies. Older backups with an orders array can be imported. Missing monthly records start empty and missing presets use the built-in catalog.

Use **Settings → Export CSV** for an order spreadsheet, or **Export CSV** on the monthly screen for fee lines and GST status. Use JSON for restoring the app. **Delete all data** clears orders and monthly records and resets settings and presets after confirmation.

## Troubleshooting
- **A month already exists.** Cancel the new entry and tap the month in the monthly list to edit it.
- **A payout shows pending.** Check linked orders or type the Etsy INR and Payoneer USD amounts. Add the after-fee rate or actual credit. You can save and return later.
- **An order is missing from Orders covered.** Open the payout that already contains it and untick it there. Save, then assign it to the right payout.
- **Bank credit looks right but profit looks high.** Check that every covered order has fulfillment costs and that the monthly invoice includes all fee lines. Check for unlinked order estimates in the breakdown.
- **Automatic fees are missing.** Verify positive merchandise plus shipping, a positive Etsy INR amount, and either explicit sales tax (including zero) or a valid buyer total. Read the live fee breakdown before saving.
- **The updated app looks old.** Close all open copies and reopen the same address online. Check Settings → About for 1.9.6. Export a backup before clearing any browser data.

The month editor shows payout-based accounting profit, recorded or estimated linked cash, outstanding RCM GST and GST marked paid. Open Audit-2.2.1.html for the independent November 23 reconciliation and test results.
