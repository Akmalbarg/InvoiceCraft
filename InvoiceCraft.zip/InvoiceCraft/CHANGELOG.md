# InvoiceCraft changelog

## Version 2.2.2

Added the isolated Product Profit Simulator, target pricing, scenario comparisons, and the complete offline CSV analysis prompt beside monthly settlement controls.

Added optional actual withdrawal fee, pre-fee rate, Payoneer transfer confirmation and withdrawal date to each payout. The RCM editor groups Etsy, withdrawal, bank and reconciliation details. Bank credit remains independent of the confirmation and takes precedence in linked-payout profit. The monthly payout detail shows each reconciliation status.

## Version 2.2.1

Added separate cash and RCM liability figures in the month editor. Fixed conflicting-month draft totals, stale refund labels, PDF dependency retry and concurrent loading, file-read errors and offline cache cleanup scope. Clarified the per-order Payoneer estimate.

## Version 2.2.0

Monthly shows eligible Etsy fees and confirmed settlements by billing month. The editor accepts referenced payment-account deductions, other settlements, and linked reversals. Payout and card allocations retain their existing records. Billing-month profit uses sale-month order estimates and fee-month expenses. The existing payout-based result remains available for cash reconciliation. No backup migration is required.

## Version 2.1.0

Added cross-month fee allocations with confirmation status, card principal and actual bank charge tracking, refunds and reversals, shared settlement limits, payment-only months, all-month dashboard profit and an offline copyable reconciliation prompt. Commercial invoices use the pre-conversion INR sale value after buyer tax. The Order view exposes the same value. Existing payouts and backup inputs retain their original order links and values.

## Version 2.0.5

Commercial invoices with automatic Etsy fee calculations show the pre-conversion INR total less the recorded or calculated INR sales tax, rounded to the nearest rupee. Previously saved orders use this corrected value when their invoices are reopened or reprinted.

2,260 automated checks passed, including four additional invoice cases. No real-browser or physical print test was run.

## Version 2.0.4

When the INR tax field is blank, InvoiceCraft converts the buyer’s USD sales tax at the Etsy payment rate and rounds it to the nearest whole rupee before calculating fees and payout. An explicit statement amount, including zero, takes priority. Previously saved orders with blank tax may show revised estimates.

2,256 automated checks passed. No real-browser tests were run for this release.

## Version 2.0.3

Sales tax is checked at the Etsy payment rate implied by the tax-inclusive INR and USD totals. For whole-rupee statement amounts the check rounds to rupees. For amounts with a fractional rupee it compares paise. The payout uses the entered statement tax.

2,251 automated checks passed, including 12 focused sales-tax checks. The July order produces $25.27 payout, $6.33 estimated USD profit and ₹601 estimated INR profit. No real-browser run for this release.

## Version 2.0.2

Order profit and downstream estimates now use the displayed USD cents for each Etsy fee, including split entries, converted INR fees and offsite advertising. Saved inputs and recorded bank receipts are preserved.

## Version 2.0.1

**IC-05 — Per-payout fee coverage.** Enter the amount of the selected monthly Etsy expenses already withheld from each payout. Enter 0 when none were withheld. Only linked, usable payouts offset the month's expenses. Explicit amounts may not exceed the month's selected fees in total. An amount incorporated in a computed bank estimate is accounted for once. Blank coverage on a statement-backed payout preserves an upper estimate and displays the possible range until confirmed.

**IC-11 — Invoice GST.** A saved monthly fee invoice replaces the order GST estimates in that month's profit. Estimated order GST is added back at each order's own exchange rate before the full invoice GST is charged. Without a monthly invoice the order estimates continue. Marking GST paid changes the outstanding balance only. USD order profit is unchanged.

# InvoiceCraft 2.0.0

## Mixed Printify costs

Every linked order independently supplies one INR fulfillment cost. A valid actual charge, including zero, wins for that order. A blank uses estimated production, actual shipping and Printify conversion at that order’s rate. The payout and month now expose actual subtotal, estimated subtotal, total and source. Pending orders retain their own cost and are included once in the month. No second deduction is made for the informational breakdown.

Version 1.9.6 already selected per-order costs in the audit fixture. The reproduced defect was the incomplete presentation. Version 2.0.0 uses one aggregation function for the linked expense and displayed amounts. An older installed version or a specific device cache was not available to reproduce the reported screen.

## Audit findings

| Audit ID | Status | Change and verification scope |
|---|---|---|
| IC-01 | Fixed | Exclude unallocated bank receipts from profit until an order is linked. The editor and month ledger identify unallocated receipts. |
| IC-02 | Fixed | Order deletion checks every payout reference. Unlink or reverse a settlement before deleting the sale. |
| IC-03 | Fixed | Validate linked IDs, uniqueness and order/transfer chronology on restore, monthly save and order date edits. Legitimate later bank dates and earlier sales remain supported. |
| IC-04 | Fixed | An incomplete payout in another month does not hide an order. Saving a reassignment confirms the move and clears the previous draft reference. A settled reference remains exclusive. |
| IC-05 | Partial — decision required | A partial month shows its possible fee exposure and a profit range. The original numeric estimate assumes the recorded receipts absorbed all selected monthly fees. The database has no transaction-level attribution. Choosing a definitive policy for outstanding fees is pending. |
| IC-06 | Fixed for settings changes | Newly saved records carry a snapshot. Before changing settings the app records the existing settings for unsnapshotted history. Reprints use the record’s seller, rates, currency and supplier information. Legacy snapshots represent the incoming backup’s settings; original issue-time settings cannot be reconstructed. Deliberate record edits still affect results. |
| IC-07 | Fixed for the audited import cases | Validate the complete candidate before replacement, including malformed records, IDs, duplicate links/numbers, dates, nonfinite values, actual costs and image fields. A validated replacement keeps the former stored bytes for recovery. Interrupted/quota operations report storage failure. |
| IC-08 | Implemented; browser durability unverified | Web Locks serialize writes where supported. Each write checks its original stored revision. Conflicting writes preserve the winner on disk and leave the losing draft available for export. A corrupt store blocks routine writes. Browsers without Web Locks use a revision comparison; exact simultaneous writes are not guaranteed atomic on that fallback. |
| IC-09 | Fixed | Compute the split sum before switching to a lump sum. The fee editor and calculation use the same automatic-fee eligibility. |
| IC-10 | Fixed for itemized fees | Automatic offsite suppresses the typed offsite component. The manual path can use the typed entry on its own. A free-form lump sum still requires the user to exclude offsite when enabling auto-offsite; its contents cannot be inferred. |
| IC-11 | Partial — decision required | Invoice GST KPI now sums full invoices, pending uses the unpaid subset, and a fee-only month includes full GST. For a sales month without a usable payout, the existing policy remains: order GST plus tax on additional fees. Adopting final invoice GST instead would change July. |
| IC-12 | Discrepancy surfaced; statement decision required | The ledger explains and itemizes the INR tax/buyer-total difference. New or changed conflicting figures prompt for confirmation. Neither saved amount is silently corrected; the original tax precedence is retained. A buyer total below merchandise and shipping is rejected. |
| IC-13 | Fixed | Orders expose independent INR and USD loss filters, INR profit and signed colors. Dashboard estimate highlights losses independently in each currency. |
| IC-14 | Fixed | Aggregate seller sales, buyer shipping, shipping difference, offsite base and currency conversion; do not use missing fields in the dashboard breakup. Remove duplicate fee conversions from order detail. |
| IC-15 | Fixed | Settled-month USD is the INR result divided by its settlement market rate. INR-only mode omits paired USD profit/credit amounts. Estimated order USD keeps the original cost basis. |
| IC-16 | Fixed | Distinguish absent settlement values from zero. Label estimated settlement inputs separately from recorded bank credit. Unallocated receipts do not increase profit. |
| IC-17 | Fixed | Cap the estimated offsite charge at USD 100 per order; automatic INR fees apply the equivalent cap at the order market rate. |
| IC-18 | Fixed for audited inputs | Reject invalid dates, amounts, nonpositive exchange defaults, impossible buyer totals, negative costs and duplicate Etsy numbers. Use zero estimated withdrawal fee on a negative payout. |
| IC-19 | Fixed | Validate self-invoice and commercial numbering. Report GST to paise on cumulative taxable amounts so line allocations add to the invoice GST. |
| IC-20 | Fixed | CSV exports actual, estimated and applied INR Printify cost with source. Show more presets beyond the first 80. Reporting windows are inclusive of today and exclude future sales. |
| IC-21 | Fixed | Restrict service-worker cleanup to versioned InvoiceCraft caches. Cache known assets and scope offline HTML fallback to navigation. |

## Previous releases

# InvoiceCraft changelog

## 1.7.0
- Auto Etsy fees now use the rupee figures from your Etsy research: type the Rs Etsy paid (after the 2.5% conversion cut) and the Rs sales tax. The app divides by 0.975, subtracts the tax, and charges transaction (6.5%, item and shipping rounded separately), regulatory (0.05%) and offsite (15%, if Yes) on that market-rate value. Processing (5% + Rs 25) is charged on the Rs Etsy paid. Each fee is rounded to whole rupees.
- The typed transaction, processing, regulatory and offsite boxes are hidden while auto fees are on, so nothing is counted twice.
- Older sales that used the USD value with tax still calculate.

## 1.6.0
- Monthly tab rate is now automatic by default: the average rate of that month's sales, weighted by order total. A rate typed on the month still wins.
- Settings, Monthly profit: choose the Monthly rate mode: Automatic, Typed rate or the rate saved with the month, or Rupees only (no dollar figures on the Monthly tab).
- Sale invoices show the INR equivalent rounded to whole rupees.

## 1.5.0
- Auto Etsy fees: type the sale value with US tax (USD) and the rupees Etsy paid, and the app calculates the transaction fee, processing fee and regulatory fee for the sale. Rates are editable in Settings (transaction 6.5%, processing 5% + Rs 25, regulatory 0.05%, currency cut 2.5%).
- The sale's exchange rate becomes the rupees Etsy paid divided by the USD value with tax.
- The invoice INR line uses that rate on the invoice total.

## 1.4.0
- Each sale keeps its own exchange rate. The INR value you type from Etsy overrides the rate for that sale. If you type nothing, the rate in Settings at the time of saving is stored with the sale, so changing Settings later does not change old sales or old invoices.
- Each month in the Monthly tab has its own rate box and keeps the rate it was saved with.
- Rupee profit on the dashboard, in the Monthly tab, in the breakup and in the CSV is added up from each sale's own rate.
- On first start, existing sales and months are fixed at the rate currently in Settings.

## 1.3.0
- Fixed: the page no longer jumps to the top when you type, toggle an option or change a setting. Scroll position is kept in editors and settings.
- New: Download PDF button on sale invoices and RCM documents. The file is saved with the invoice number (or RCM number and month) as its name. The Print button still works and also sets the name.
- File names: characters that cannot be used in file names become a dash, so INV/2026/005 saves as INV-2026-005.
- Automatic invoice and RCM numbers now skip numbers already used. Saving a sale with a duplicate invoice number asks first. A month can no longer be saved twice in the Monthly tab, even when editing.

## 1.2.0
- Sale invoices: invoice date and payment date fields (invoice date defaults to the order date).
- Printing a document now sets the PDF file name automatically: sale invoices use a pattern (default the invoice number), RCM documents use the RCM number and month, profit sheets use the order ID.

## 1.1.2
- Labels now say HSN (not HS code).
- RCM self-invoice and payment voucher use a separate SAC code for each Etsy fee line (Settings, RCM self-invoice), with a fallback code.

## 1.1.1
- Printing: each document is measured and scaled so it fits on one page of the chosen paper size, instead of spilling onto a second page.

## 1.1.0
- Paper sizes for all printed documents: A3, A4, A5, A6, B4, B5, Letter, Half letter, Executive, Legal, Tabloid, or a custom size, with portrait or landscape and adjustable margin. Content scales to fit.

## 1.0.0
- Per-order profit calculator: offsite fee (15%, optional), typed Etsy fees with split, actual shipping cost and shipping difference, Payoneer, Printify conversion, RCM GST.
- Monthly tab: monthly Etsy fee invoices, RCM GST, profit after monthly fees.
- RCM self-invoice and payment voucher with auto numbering.
- Customer Commercial Invoice (PAN/IEC, ship-to, HS code, discount, INR value from Etsy, total in words, declaration, signature).
- Presets from your Profit sheet (editable), dashboard, search and filters, JSON/CSV backup, offline PWA.
- Print paper size option (A4, Letter, Legal), phone menu position and bottom-button lift settings.

Version number lives in index.html (VER) and the cache name in sw.js. Change both on each release.
