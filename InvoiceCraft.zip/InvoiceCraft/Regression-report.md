# InvoiceCraft 2.1.0 regression report

## Version 2.1.0 verification

The uploaded source archive matched the 2.0.4 release byte for byte at the file-content level. Testing used isolated copies of the original audit fixture and the updated four-order backup. No settlement allocations, card entries or revisions were written to those backups.

### August 17 settlement

The June CSV rows net to −₹475. July contains a ₹475 card credit, 36 listing-type fees of ₹19 and one ₹2,968 sale. The sale has ₹194 buyer tax, ₹173 processing, ₹185 transaction fees, ₹1 regulatory fee, ₹3 TDS and ₹14 TCS. Together the order deductions are ₹570. Reconstructing June and July activity gives a ₹1,714 balance at the end of July. In the supplied CSV row order, August has 20 listing fees of ₹19 and ₹12 of ads before the ₹1,322 transfer. The reconstructed balance clears to zero on that transfer. The ₹51 ad charge posted August 18 is outside the cutoff.

The records support allocating ₹684 to July and ₹392 to August. July’s CSV labels all 36 rows “Listing fee”. The backup classifies ₹665 as listing and ₹19 as renewal. The CSV lacks an explicit renewal label, opening balance column and per-fee payout ID. The July card entry matches the reconstructed June shortfall but does not name a billing month. These distinctions matter if another statement supplies a different opening balance or allocation.

August’s full selected expenses are ₹1,004, leaving ₹612 outside this transfer. The backup keeps the August 17 payout on the July record, linked to the July sale. Its actual bank credit is ₹1,250.41. With the proposed allocations entered in a test copy, the payout is included once, using that credit. July retains its ₹684 expense. The ₹392 already removed from the receipt is added back in July and recognized in August. The shipped application contains no prefilled settlement edits.

### Commercial invoices

The October CSV records ₹3,020 on the order payment line and ₹244 separately as buyer tax. Other fees are separate lines. That identifies the correct input as the tax-inclusive sale posting. The order snapshot sets conversion at 2.5%. The CSV does not specify the underlying exchange quote or separately itemize that conversion fee. The application uses the configured convention to reverse it. The calculation for INV-0002 is 3,020 ÷ 0.975 − 244 = ₹2,853.435897…, or ₹2,853 on a whole-rupee invoice. The previous template multiplied $29.98 by the buyer-total-derived rate, yielding ₹2,846.75. All four invoices in the updated backup were rendered and checked. USD totals use the original item and buyer shipping amounts.

| Invoice | Previous INR before whole-rupee display | Corrected INR before whole-rupee display | New display |
|---|---:|---:|---:|
| INV-0001 | 2,846.83 | 2,854.10 | ₹2,854 |
| INV-0002 | 2,846.75 | 2,853.44 | ₹2,853 |
| INV-0003 | 2,845.37 | 2,850.10 | ₹2,850 |
| INV-0004 | 2,593.54 | 2,596.90 | ₹2,597 |

### Card entries

| Etsy principal | Extra bank charge | Cash debit | Additional profit deduction |
|---:|---:|---:|---:|
| ₹2,317 | ₹81 | ₹2,398 | ₹81 |
| ₹612 | ₹26 | ₹638 | ₹26 |

The examples were entered only in test copies. No bank markup or tax rate was assumed. The payment or refund date determines the month of the bank charge. The billing allocations determine which principal balances are settled. A refund of ₹100 principal and ₹10 bank charges reopens ₹100 of fees and restores ₹10 of profit.

### Executed coverage

2,326 checks passed, with zero final failures. This comprises the 1,474 original audit checks with documented corrections, 734 mixed Printify checks, four storage checks, 17 fee/GST checks, ten USD rounding checks, 21 sales tax and invoice checks, 49 settlement and interaction checks, 13 statement checks and four additional saved-invoice comparisons. The original IC-01 through IC-21 dispositions and historical release notes follow. The current CSV lists each executed check.

Verified nested card and payout records through the export/import handlers and simulated refresh. Tested genuine and false tax warnings, duplicate allocations, over-allocation against net fees, excessive refunds, deletion of referenced records, partial settlements, charge-only changes, multiple payments, several billing months, payment-only months, settings snapshots and the three clipboard outcomes. The clipboard, persistence, service-worker and interaction checks use simulated browser APIs.

Chromium startup was blocked before the page opened. Physical mobile touch, visual overflow, OS clipboard permissions, actual offline reopening and installed-app upgrades, a printed page, and a downloaded PDF were not verified on a real browser in this release. Preview, print and PDF actions were checked to use the same tested invoice renderer. The prior regression table describes the scope of earlier issue fixes, not additional real-device passes.


## Version 2.0.5

Commercial invoices with automatic Etsy fee calculations show the pre-conversion INR total less the recorded or calculated INR sales tax, rounded to the nearest rupee. Previously saved orders use this corrected value when their invoices are reopened or reprinted.

2,260 automated checks passed, including four additional invoice cases. No real-browser or physical print test was run.

## Version 2.0.4

When the INR tax field is blank, InvoiceCraft converts the buyer’s USD sales tax at the Etsy payment rate and rounds it to the nearest whole rupee before calculating fees and payout. An explicit statement amount, including zero, takes priority. Previously saved orders with blank tax may show revised estimates.

2,256 automated checks passed. No real-browser tests were run for this release.

## Version 2.0.3

Sales tax is checked at the Etsy payment rate implied by the tax-inclusive INR and USD totals. For whole-rupee statement amounts the check rounds to rupees. For amounts with a fractional rupee it compares paise. The payout uses the entered statement tax.

2,251 automated checks passed, including 12 focused sales-tax checks. The July order produces $25.27 payout, $6.33 estimated USD profit and ₹601 estimated INR profit. No real-browser run for this release.

## Version 2.0.2

All 2,239 automated checks passed, including 1,474 audit checks, 734 mixed-cost checks, 17 fee and GST checks, four storage checks and ten targeted rounding checks. The monthly dashboard expectation uses independently recalculated profits under the updated rule. Browser testing was blocked because Chromium could not open its required socket.

## Version 2.0.1

**IC-05 — Per-payout fee coverage.** Enter the amount of the selected monthly Etsy expenses already withheld from each payout. Enter 0 when none were withheld. Only linked, usable payouts offset the month's expenses. Explicit amounts may not exceed the month's selected fees in total. An amount incorporated in a computed bank estimate is accounted for once. Blank coverage on a statement-backed payout preserves an upper estimate and displays the possible range until confirmed.

**IC-11 — Invoice GST.** A saved monthly fee invoice replaces the order GST estimates in that month's profit. Estimated order GST is added back at each order's own exchange rate before the full invoice GST is charged. Without a monthly invoice the order estimates continue. Marking GST paid changes the outstanding balance only. USD order profit is unchanged.

## Results

2,229 checks passed, 0 failed. The release ran all 1,474 audit cases, 734 mixed Printify cases, 4 simulated concurrent-storage checks and 17 focused fee and GST checks. The two open accounting-policy cases from 2.0.0 now pass. The independent monthly expectation now uses the approved invoice GST basis. The partial payout fixture explicitly records zero withholding when the fee is known to be outstanding. All row-level results are in tests/results.csv.

| Scenario | Expected | Actual |
|---|---:|---:|
| ₹100 monthly fees, none withheld, ₹4,000 before fees | ₹3,900 | ₹3,900 |
| ₹100 monthly fees, ₹40 withheld, ₹4,000 before remaining fees | ₹3,940 | ₹3,940 |
| July monthly profit | −₹160.90 | −₹160.90 |
| October upper estimate (old payout has blank fee coverage) | −₹97.53 | −₹97.53 |
| October if ₹350 selected fees are confirmed fully withheld | −₹97.53 | −₹97.53 |
| Mixed Printify, actual ₹3,300 and estimated ₹2,950 | ₹6,250 | ₹6,250 |

The October bank statement fields are preserved. With no withholding value, the range is −₹447.53 to −₹97.53. Enter the amount confirmed by the Etsy statement to resolve that range. The all-month upper estimate is −₹5,409.15.

The JS harness uses simulated DOM and storage boundaries. Actual Android/mobile interactions, PDF output, installed-app update and real-browser persistence remain unverified. Technical limitations of the earlier release and the two unresolved source-statement tax discrepancies remain applicable. This update does not reclassify buyer sales tax or change the saved business records.

### Audit issue register

| Audit ID | Status | Change and verification scope |
|---|---|---|
| IC-01 | Fixed | Exclude unallocated bank receipts from profit until an order is linked. The editor and month ledger identify unallocated receipts. |
| IC-02 | Fixed | Order deletion checks every payout reference. Unlink or reverse a settlement before deleting the sale. |
| IC-03 | Fixed | Validate linked IDs, uniqueness and order/transfer chronology on restore, monthly save and order date edits. Legitimate later bank dates and earlier sales remain supported. |
| IC-04 | Fixed | An incomplete payout in another month does not hide an order. Saving a reassignment confirms the move and clears the previous draft reference. A settled reference remains exclusive. |
| IC-05 | Fixed | Explicit withholding offsets selected monthly expenses once. Missing statement coverage is labeled as an upper estimate with a range. |
| IC-06 | Fixed for settings changes | Newly saved records carry a snapshot. Before changing settings the app records the existing settings for unsnapshotted history. Reprints use the record’s seller, rates, currency and supplier information. Legacy snapshots represent the incoming backup’s settings; original issue-time settings cannot be reconstructed. Deliberate record edits still affect results. |
| IC-07 | Fixed for the audited import cases | Validate the complete candidate before replacement, including malformed records, IDs, duplicate links/numbers, dates, nonfinite values, actual costs and image fields. A validated replacement keeps the former stored bytes for recovery. Interrupted/quota operations report storage failure. |
| IC-08 | Implemented; browser durability unverified | Web Locks serialize writes where supported. Each write checks its original stored revision. Conflicting writes preserve the winner on disk and leave the losing draft available for export. A corrupt store blocks routine writes. Browsers without Web Locks use a revision comparison; exact simultaneous writes are not guaranteed atomic on that fallback. |
| IC-09 | Fixed | Compute the split sum before switching to a lump sum. The fee editor and calculation use the same automatic-fee eligibility. |
| IC-10 | Fixed for itemized fees | Automatic offsite suppresses the typed offsite component. The manual path can use the typed entry on its own. A free-form lump sum still requires the user to exclude offsite when enabling auto-offsite; its contents cannot be inferred. |
| IC-11 | Fixed | Saved invoices replace order GST estimates. The full invoice and unpaid balances remain separately traceable. |
| IC-12 | Discrepancy surfaced; statement decision required | The ledger explains and itemizes the INR tax/buyer-total difference. New or changed conflicting figures prompt for confirmation. Neither saved amount is silently corrected; the original tax precedence is retained. A buyer total below merchandise and shipping is rejected. |
| IC-13 | Fixed | Orders expose independent INR and USD loss filters, INR profit and signed colors. Dashboard estimate highlights losses independently in each currency. |
| IC-14 | Fixed | Aggregate seller sales, buyer shipping, shipping difference, offsite base and currency conversion; do not use missing fields in the dashboard breakup. Remove duplicate fee conversions from order detail. |
| IC-15 | Fixed | Settled-month USD is the INR result divided by its settlement market rate. INR-only mode omits paired USD profit/credit amounts. Estimated order USD keeps the original cost basis. |
| IC-16 | Fixed | Distinguish absent settlement values from zero. Label estimated settlement inputs separately from recorded bank credit. Unallocated receipts do not increase profit. |
| IC-17 | Fixed | Cap the estimated offsite charge at USD 100 per order; automatic INR fees apply the equivalent cap at the order market rate. |
| IC-18 | Fixed for audited inputs | Reject invalid dates, amounts, nonpositive exchange defaults, impossible buyer totals, negative costs and duplicate Etsy numbers. Use zero estimated withdrawal fee on a negative payout. |
| IC-19 | Fixed | Validate self-invoice and commercial numbering. Report GST to paise on cumulative taxable amounts so line allocations add to the invoice GST. |
| IC-20 | Fixed | CSV exports actual, estimated and applied INR Printify cost with source. Show more presets beyond the first 80. Reporting windows are inclusive of today and exclude future sales. |
| IC-21 | Fixed | Restrict service-worker cleanup to versioned InvoiceCraft caches. Cache known assets and scope offline HTML fallback to navigation. |
